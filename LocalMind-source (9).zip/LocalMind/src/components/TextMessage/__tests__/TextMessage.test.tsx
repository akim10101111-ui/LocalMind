import * as utils from '@flyerhq/react-native-link-preview/lib/utils';
import {fireEvent, render, waitFor} from '@testing-library/react-native';
import * as React from 'react';
import {Linking} from 'react-native';

import {derivedTextMessage} from '../../../../jest/fixtures';
import {render as renderWithProviders} from '../../../../jest/test-utils';
import {assistant} from '../../../utils/chat';
import {TextMessage} from '../TextMessage';

describe('text message', () => {
  // eslint-disable-next-line jest/no-disabled-tests
  it.skip('renders preview image and handles link press', async () => {
    const link = 'https://github.com/flyerhq/';
    const getPreviewDataMock = jest
      .spyOn(utils, 'getPreviewData')
      .mockResolvedValue({
        description: 'description',
        image: {
          height: 460,
          url: 'https://avatars2.githubusercontent.com/u/59206044',
          width: 460,
        },
        link,
        title: 'title',
      });
    const openUrlMock = jest.spyOn(Linking, 'openURL');
    const {getByRole, getByText, debug} = render(
      <TextMessage
        message={{
          ...derivedTextMessage,
          author: {id: 'newUserId', firstName: 'John'},
          text: link,
        }}
        messageWidth={440}
        onPreviewDataFetched={jest.fn}
        showName
        usePreviewData
      />,
    );
    debug();
    const image = getByRole('image');
    expect(image).toBeDefined();
    const text = getByText(link);
    fireEvent.press(text);
    expect(openUrlMock).toHaveBeenCalledWith(link);
    getPreviewDataMock.mockRestore();
    openUrlMock.mockRestore();
  });

  // eslint-disable-next-line jest/no-disabled-tests
  it.skip('renders preview image without https and handles link press', async () => {
    expect.assertions(2);
    const link = 'github.com/flyerhq/';
    const getPreviewDataMock = jest
      .spyOn(utils, 'getPreviewData')
      .mockResolvedValue({
        description: 'description',
        image: {
          height: 460,
          url: 'https://avatars2.githubusercontent.com/u/59206044',
          width: 460,
        },
        link,
        title: 'title',
      });
    const openUrlMock = jest.spyOn(Linking, 'openURL');
    const {getByRole, getByText} = render(
      <TextMessage
        message={{...derivedTextMessage, text: link}}
        messageWidth={440}
        onPreviewDataFetched={jest.fn}
        showName={false}
        usePreviewData
      />,
    );
    await waitFor(() => getByRole('image'));
    const image = getByRole('image');
    expect(image).toBeDefined();
    const text = getByText(link);
    fireEvent.press(text);
    expect(openUrlMock).toHaveBeenCalledWith('https://' + link);
    getPreviewDataMock.mockRestore();
    openUrlMock.mockRestore();
  });

  it('renders a step through its visible content, not raw content', () => {
    const echo = '{"name": "web_search", "arguments": {"query": "Firecrawl"}}';
    const call = {
      id: 'c0',
      function: {name: 'web_search', arguments: '{"query": "Firecrawl"}'},
    };
    const {queryByText, rerender} = renderWithProviders(
      <TextMessage
        message={derivedTextMessage}
        messageWidth={440}
        showName={false}
        usePreviewData={false}
        step={{content: echo}}
      />,
    );
    expect(queryByText(/web_search/)).not.toBeNull();

    rerender(
      <TextMessage
        message={derivedTextMessage}
        messageWidth={440}
        showName={false}
        usePreviewData={false}
        step={{content: echo, toolCalls: [call]}}
      />,
    );
    expect(queryByText(/web_search/)).toBeNull();
  });

  describe('selection and block popup', () => {
    const {EnrichedMarkdownText} = require('react-native-enriched-markdown');
    const markdownProps = () =>
      (EnrichedMarkdownText as jest.Mock).mock.calls[0][0];

    beforeEach(() => {
      (EnrichedMarkdownText as jest.Mock).mockClear();
    });

    it('renders an assistant message without a step selectable', () => {
      renderWithProviders(
        <TextMessage
          message={{...derivedTextMessage, author: assistant, text: 'Hi'}}
          messageWidth={440}
          showName={false}
          usePreviewData={false}
        />,
      );

      expect(markdownProps()).toEqual(
        expect.objectContaining({
          selectable: true,
          enableBlockContextMenu: true,
        }),
      );
    });

    it('turns selection and the block popup off on a user row', () => {
      renderWithProviders(
        <TextMessage
          message={{...derivedTextMessage, text: 'Hi'}}
          messageWidth={440}
          showName={false}
          usePreviewData={false}
        />,
      );

      expect(markdownProps()).toEqual(
        expect.objectContaining({
          selectable: false,
          enableBlockContextMenu: false,
        }),
      );
    });

    it('keeps selection and the block popup on assistant step content', () => {
      renderWithProviders(
        <TextMessage
          message={{...derivedTextMessage, author: assistant}}
          messageWidth={440}
          showName={false}
          usePreviewData={false}
          step={{content: 'Step content'}}
        />,
      );

      expect(markdownProps()).toEqual(
        expect.objectContaining({
          selectable: true,
          enableBlockContextMenu: true,
        }),
      );
    });

    it('keeps selection and the block popup on a system row', () => {
      renderWithProviders(
        <TextMessage
          message={{
            ...derivedTextMessage,
            author: assistant,
            text: 'Context is full',
            metadata: {system: true},
          }}
          messageWidth={440}
          showName={false}
          usePreviewData={false}
        />,
      );

      expect(markdownProps()).toEqual(
        expect.objectContaining({
          selectable: true,
          enableBlockContextMenu: true,
        }),
      );
    });
  });

  it('renders call-shaped JSON in a message without a step', () => {
    const echo = '{"name": "web_search", "arguments": {"query": "Firecrawl"}}';
    const {queryByText} = renderWithProviders(
      <TextMessage
        message={{...derivedTextMessage, text: echo}}
        messageWidth={440}
        showName={false}
        usePreviewData={false}
      />,
    );
    expect(queryByText(/web_search/)).not.toBeNull();
  });

  it('renders and handles email press', async () => {
    expect.assertions(1);
    const email = 'john@flyer.chat';
    const getPreviewDataMock = jest
      .spyOn(utils, 'getPreviewData')
      .mockResolvedValue({});
    const openUrlMock = jest.spyOn(Linking, 'openURL');
    const {getByText} = render(
      <TextMessage
        message={{
          ...derivedTextMessage,
          author: {id: 'newUserId', firstName: 'John'},
          text: email,
        }}
        messageWidth={440}
        onPreviewDataFetched={jest.fn}
        showName
        usePreviewData
      />,
    );
    await waitFor(() => getByText(email));
    const text = getByText(email);
    fireEvent.press(text);
    expect(openUrlMock).toHaveBeenCalledWith(`mailto:${email}`);
    getPreviewDataMock.mockRestore();
    openUrlMock.mockRestore();
  });
});
