import {Platform} from 'react-native';

import type {EngineId} from '../../services/tts';

/**
 * Per-engine numeric/visual metadata used across the sheet for branding,
 * spec strips and group headers. Single source of truth — extend here
 * when adding a new engine.
 *
 * Localized strings (title, tagline, tier label) live in
 * `voiceAndSpeech.engine*` keys in en.json — look them up at the call
 * site so translators can localize without touching this table.
 *
 * RAM is the peak resident MB measured during synthesis (E2E memory
 * profile, iPhone 17 Pro simulator and Pixel emulator, Release). Each value
 * is the higher of the two platforms, rounded. Approximate, not disk
 * footprint. Phonon can't run on the x86_64 emulator: its value is the Pixel 9
 * per-launch peak less Kitten's phone-vs-emulator offset, rounded up to 50.
 * Kokoro on Android runs int8: its value is the int8 peak measured on a phone.
 */
export interface EngineMeta {
  /** ~MB on disk after install (0 for system). */
  sizeMb: number;
  /** ~Peak RAM during synthesis, MB (0 for system / unknown). */
  ramMb: number;
  /** Voice count for spec strip. */
  voices: number;
  accent: string;
  gradientFrom: string;
  gradientTo: string;
}

export const ENGINE_META: Record<EngineId, EngineMeta> = {
  kitten: {
    sizeMb: 57,
    ramMb: 350,
    voices: 8,
    accent: '#F29547',
    gradientFrom: 'rgba(242, 149, 71, 0.12)',
    gradientTo: 'rgba(242, 149, 71, 0.02)',
  },
  kokoro: {
    sizeMb: Platform.OS === 'android' ? 107 : 330,
    ramMb: Platform.OS === 'android' ? 310 : 640,
    voices: 30,
    accent: '#6F5CD6',
    gradientFrom: 'rgba(111, 92, 214, 0.14)',
    gradientTo: 'rgba(111, 92, 214, 0.02)',
  },
  supertonic: {
    sizeMb: 380,
    ramMb: 670,
    voices: 10,
    accent: '#1E4DF6',
    gradientFrom: 'rgba(30, 77, 246, 0.14)',
    gradientTo: 'rgba(30, 77, 246, 0.02)',
  },
  phonon: {
    sizeMb: Platform.OS === 'ios' ? 164 : 64,
    ramMb: 300,
    voices: 8,
    accent: '#0E9F8E',
    gradientFrom: 'rgba(14, 159, 142, 0.14)',
    gradientTo: 'rgba(14, 159, 142, 0.02)',
  },
  system: {
    sizeMb: 0,
    ramMb: 0,
    voices: 0,
    accent: '#7B8896',
    gradientFrom: 'rgba(123, 136, 150, 0.10)',
    gradientTo: 'rgba(123, 136, 150, 0.02)',
  },
};
