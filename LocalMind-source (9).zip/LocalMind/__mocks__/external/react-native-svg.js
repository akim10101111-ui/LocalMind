module.exports = 'SvgMock';
