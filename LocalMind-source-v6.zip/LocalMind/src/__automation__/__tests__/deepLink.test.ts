import {dispatchAutomationDeepLink} from '../deepLink';

import type {DeepLinkParams} from '../../services/DeepLinkService';

import {
  takeMemorySnapshot,
  clearMemorySnapshots,
} from '../../utils/memoryProfile';

jest.mock('../../utils/memoryProfile', () => ({
  takeMemorySnapshot: jest.fn().mockResolvedValue(undefined),
  clearMemorySnapshots: jest.fn().mockResolvedValue(undefined),
  readMemorySnapshots: jest.fn().mockResolvedValue(''),
}));

// Helper: every DeepLinkParams has url+scheme+host at minimum; tests only
// care about host + queryParams so we fill the rest with placeholders.
const makeParams = (overrides: Partial<DeepLinkParams>): DeepLinkParams => ({
  url: 'pocketpal://placeholder',
  scheme: 'pocketpal',
  host: 'memory',
  ...overrides,
});

describe('dispatchAutomationDeepLink', () => {
  beforeEach(() => {
    jest.clearAllMocks();
  });


  it('takes a memory snapshot for host=memory + cmd=snap::<label>', async () => {
    const handled = await dispatchAutomationDeepLink(
      makeParams({host: 'memory', queryParams: {cmd: 'snap::model_loaded'}}),
    );

    expect(handled).toBe(true);
    expect(takeMemorySnapshot).toHaveBeenCalledWith('model_loaded');
    expect(clearMemorySnapshots).not.toHaveBeenCalled();
  });

  it('defaults to "unnamed" when snap:: has no label', async () => {
    const handled = await dispatchAutomationDeepLink(
      makeParams({host: 'memory', queryParams: {cmd: 'snap::'}}),
    );

    expect(handled).toBe(true);
    expect(takeMemorySnapshot).toHaveBeenCalledWith('unnamed');
  });

  it('clears snapshots for host=memory + cmd=clear::snapshots', async () => {
    const handled = await dispatchAutomationDeepLink(
      makeParams({host: 'memory', queryParams: {cmd: 'clear::snapshots'}}),
    );

    expect(handled).toBe(true);
    expect(clearMemorySnapshots).toHaveBeenCalled();
    expect(takeMemorySnapshot).not.toHaveBeenCalled();
  });

  it('returns true but ignores unrecognized cmd under host=memory', async () => {
    const handled = await dispatchAutomationDeepLink(
      makeParams({host: 'memory', queryParams: {cmd: 'unknown::command'}}),
    );

    // Contract: host=memory is "handled" so the caller does not fall through
    // to chat-routing, even if the specific cmd is a no-op.
    expect(handled).toBe(true);
    expect(takeMemorySnapshot).not.toHaveBeenCalled();
    expect(clearMemorySnapshots).not.toHaveBeenCalled();
  });

  it('returns false when host is not memory', async () => {
    const handled = await dispatchAutomationDeepLink(
      makeParams({host: 'chat', queryParams: {palId: 'pal-1'}}),
    );

    expect(handled).toBe(false);
    expect(takeMemorySnapshot).not.toHaveBeenCalled();
    expect(clearMemorySnapshots).not.toHaveBeenCalled();
  });

  it('returns false when host=memory but no cmd is provided', async () => {
    const handled = await dispatchAutomationDeepLink(
      makeParams({host: 'memory', queryParams: {}}),
    );

    expect(handled).toBe(false);
    expect(takeMemorySnapshot).not.toHaveBeenCalled();
    expect(clearMemorySnapshots).not.toHaveBeenCalled();
  });

  it('returns false when host=memory but queryParams is absent', async () => {
    const handled = await dispatchAutomationDeepLink(
      makeParams({host: 'memory'}),
    );

    expect(handled).toBe(false);
    expect(takeMemorySnapshot).not.toHaveBeenCalled();
    expect(clearMemorySnapshots).not.toHaveBeenCalled();
  });

  describe('bench host', () => {
    it('navigates to BenchmarkRunner with autostart:false for pocketpal://e2e/benchmark', async () => {
      const navigate = jest.fn();
      const handled = await dispatchAutomationDeepLink(
        makeParams({
          url: 'pocketpal://e2e/benchmark',
          host: 'e2e',
        }),
        {navigate},
      );

      expect(handled).toBe(true);
      // Bare URL still routes; autostart false keeps the screen idle.
      expect(navigate).toHaveBeenCalledWith('BenchmarkRunner', {
        autostart: false,
      });
    });

    it('navigates with autostart:true for pocketpal://e2e/benchmark?autostart=1', async () => {
      const navigate = jest.fn();
      const handled = await dispatchAutomationDeepLink(
        makeParams({
          url: 'pocketpal://e2e/benchmark?autostart=1',
          host: 'e2e',
        }),
        {navigate},
      );

      expect(handled).toBe(true);
      expect(navigate).toHaveBeenCalledWith('BenchmarkRunner', {
        autostart: true,
      });
    });

    it('navigates with autostart:false for pocketpal://e2e/benchmark?autostart=0', async () => {
      const navigate = jest.fn();
      const handled = await dispatchAutomationDeepLink(
        makeParams({
          url: 'pocketpal://e2e/benchmark?autostart=0',
          host: 'e2e',
        }),
        {navigate},
      );

      expect(handled).toBe(true);
      expect(navigate).toHaveBeenCalledWith('BenchmarkRunner', {
        autostart: false,
      });
    });

    it('returns true even when no navigation is supplied (cold-launch path handles nav itself)', async () => {
      const handled = await dispatchAutomationDeepLink(
        makeParams({
          url: 'pocketpal://e2e/benchmark',
          host: 'e2e',
        }),
      );
      expect(handled).toBe(true);
    });

    it('returns false when host=e2e but the URL does not include /benchmark', async () => {
      const navigate = jest.fn();
      const handled = await dispatchAutomationDeepLink(
        makeParams({
          url: 'pocketpal://e2e/other',
          host: 'e2e',
        }),
        {navigate},
      );

      expect(handled).toBe(false);
      expect(navigate).not.toHaveBeenCalled();
    });
  });

  describe('asr host', () => {
    it('runs the asr command for host=asr + cmd=state::<...>', async () => {
      const runAsrCommand = jest.fn().mockResolvedValue(undefined);
      jest.doMock('../asrAutomation', () => ({runAsrCommand}));
      jest.resetModules();
      const {dispatchAutomationDeepLink: dispatch} = require('../deepLink');

      const handled = await dispatch(
        makeParams({host: 'asr', queryParams: {cmd: 'state::ready'}}),
      );

      expect(handled).toBe(true);
      expect(runAsrCommand).toHaveBeenCalledWith('state::ready');
      jest.dontMock('../asrAutomation');
    });

    it('returns false when host=asr but no cmd is provided', async () => {
      const handled = await dispatchAutomationDeepLink(
        makeParams({host: 'asr', queryParams: {}}),
      );

      expect(handled).toBe(false);
    });
  });

  describe('voice host', () => {
    it('runs the voice command for host=voice + cmd', async () => {
      const runVoiceCommand = jest.fn().mockResolvedValue(undefined);
      jest.doMock('../voiceAutomation', () => ({runVoiceCommand}));
      jest.resetModules();
      const {dispatchAutomationDeepLink: dispatch} = require('../deepLink');

      const handled = await dispatch(
        makeParams({host: 'voice', queryParams: {cmd: 'state::listening'}}),
      );

      expect(handled).toBe(true);
      expect(runVoiceCommand).toHaveBeenCalledWith('state::listening');
      jest.dontMock('../voiceAutomation');
    });

    it('returns false when host=voice but no cmd is provided', async () => {
      const handled = await dispatchAutomationDeepLink(
        makeParams({host: 'voice', queryParams: {}}),
      );

      expect(handled).toBe(false);
    });
  });
});
