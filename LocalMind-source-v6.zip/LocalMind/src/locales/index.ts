import _ from 'lodash';
import dayjs from 'dayjs';

import enData from './en.json';

import type {Translations} from './types';

// ─── Language Registry (single source of truth) ──────────────────────
// To add a language: 1) add entry here, 2) place JSON in src/locales/,
// 3) add case to requireLanguageData(), 4) add getter to l10n object,
// 5) add the dayjs locale to initLocale(), 6) run `yarn verify:fonts` — if it
// reports letters missing from the bundled Fraunces subset, add the locale to
// NON_LATIN_LOCALES in src/theme/tokens/typography.ts so headlines fall back
// to Inter. Step 6 is not optional and not decidable by eye: Polish is Latin
// script but still needs the fallback.
const languageRegistry = {
  en: {displayName: 'English (EN)'},
  ar: {displayName: 'العربية (AR)'},
  es: {displayName: 'Español (ES)'},
  fa: {displayName: 'فارسی (FA)'},
  he: {displayName: 'עברית (HE)'},
  id: {displayName: 'Indonesia (ID)'},
  ja: {displayName: '日本語 (JA)'},
  ko: {displayName: '한국어 (KO)'},
  ms: {displayName: 'Melayu (MS)'},
  pl: {displayName: 'Polski (PL)'},
  pt: {displayName: 'Português (PT)'},
  pt_BR: {displayName: 'Português (PT_BR)'},
  ru: {displayName: 'Русский (RU)'},
  uk: {displayName: 'Українська (UK)'},
  zh: {displayName: '中文 (ZH)'},
  zh_Hant: {displayName: '繁體中文 (ZH_HANT)'},
} as const;

export type AvailableLanguage = keyof typeof languageRegistry;
export const supportedLanguages = Object.keys(
  languageRegistry,
) as AvailableLanguage[];

export const languageDisplayNames: Record<AvailableLanguage, string> = {
  en: languageRegistry.en.displayName,
  ar: languageRegistry.ar.displayName,
  es: languageRegistry.es.displayName,
  fa: languageRegistry.fa.displayName,
  he: languageRegistry.he.displayName,
  id: languageRegistry.id.displayName,
  ja: languageRegistry.ja.displayName,
  ko: languageRegistry.ko.displayName,
  ms: languageRegistry.ms.displayName,
  pl: languageRegistry.pl.displayName,
  pt: languageRegistry.pt.displayName,
  pt_BR: languageRegistry.pt_BR.displayName,
  ru: languageRegistry.ru.displayName,
  uk: languageRegistry.uk.displayName,
  zh: languageRegistry.zh.displayName,
  zh_Hant: languageRegistry.zh_Hant.displayName,
};

// ─── Lazy Loading ────────────────────────────────────────────────────
const cache: Partial<Record<AvailableLanguage, Translations>> = {
  en: enData,
};

// Metro bundles these at build time, but JS doesn't parse them until require() is called
function requireLanguageData(lang: AvailableLanguage): object | null {
  switch (lang) {
    case 'ar':
      return require('./ar.json');
    case 'es':
      return require('./es.json');
    case 'fa':
      return require('./fa.json');
    case 'he':
      return require('./he.json');
    case 'id':
      return require('./id.json');
    case 'ja':
      return require('./ja.json');
    case 'ko':
      return require('./ko.json');
    case 'ms':
      return require('./ms.json');
    case 'pl':
      return require('./pl.json');
    case 'pt':
      return require('./pt.json');
    case 'pt_BR':
      return require('./pt_BR.json');
    case 'ru':
      return require('./ru.json');
    case 'uk':
      return require('./uk.json');
    case 'zh':
      return require('./zh.json');
    case 'zh_Hant':
      return require('./zh_Hant.json');
    default:
      return null;
  }
}

function getTranslations(lang: AvailableLanguage): Translations {
  if (cache[lang]) {
    return cache[lang]!;
  }
  const langData = requireLanguageData(lang);
  const merged: Translations = langData
    ? _.merge({}, enData, langData)
    : enData;
  cache[lang] = merged;
  return merged;
}

// Expose cache keys for testing lazy-loading behavior
export function _testGetCacheKeys(): string[] {
  return Object.keys(cache);
}

// ─── Getter-based l10n object ────────────────────────────────────────
// Looks like {en: Translations, id: Translations, ...} but only loads
// non-en languages on first property access.
export const l10n = {
  get en(): Translations {
    return enData;
  },
  get ar(): Translations {
    return getTranslations('ar');
  },
  get es(): Translations {
    return getTranslations('es');
  },
  get fa(): Translations {
    return getTranslations('fa');
  },
  get he(): Translations {
    return getTranslations('he');
  },
  get id(): Translations {
    return getTranslations('id');
  },
  get ja(): Translations {
    return getTranslations('ja');
  },
  get ko(): Translations {
    return getTranslations('ko');
  },
  get ms(): Translations {
    return getTranslations('ms');
  },
  get pl(): Translations {
    return getTranslations('pl');
  },
  get pt(): Translations {
    return getTranslations('pt');
  },
  get pt_BR(): Translations {
    return getTranslations('pt_BR');
  },
  get ru(): Translations {
    return getTranslations('ru');
  },
  get uk(): Translations {
    return getTranslations('uk');
  },
  get zh(): Translations {
    return getTranslations('zh');
  },
  get zh_Hant(): Translations {
    return getTranslations('zh_Hant');
  },
};

// ─── Interpolation helper ────────────────────────────────────────────
/**
 * Typed interpolation helper.
 * Replaces all {{placeholder}} patterns in the template with values from the params object.
 *
 * @example
 * t(l10n.en.storage.lowStorage, { modelSize: '4 GB', freeSpace: '2 GB' })
 * // => 'Storage low! Model 4 GB > 2 GB free'
 */
export function t(
  template: string,
  params: Record<string, string | number>,
): string {
  return template.replace(/\{\{(\w+)\}\}/g, (_match, key) =>
    String(params[key] ?? `{{${key}}}`),
  );
}

// ─── Dayjs locale ───────────────────────────────────────────────────
export const initLocale = (locale?: AvailableLanguage) => {
  const locales: Record<AvailableLanguage, unknown> = {
    en: require('dayjs/locale/en'),
    ar: require('dayjs/locale/ar'),
    es: require('dayjs/locale/es'),
    fa: require('dayjs/locale/fa'),
    he: require('dayjs/locale/he'),
    id: require('dayjs/locale/id'),
    ja: require('dayjs/locale/ja'),
    ko: require('dayjs/locale/ko'),
    ms: require('dayjs/locale/ms'),
    pl: require('dayjs/locale/pl'),
    pt: require('dayjs/locale/pt'),
    pt_BR: require('dayjs/locale/pt-br'),
    ru: require('dayjs/locale/ru'),
    uk: require('dayjs/locale/uk'),
    zh: require('dayjs/locale/zh'),
    zh_Hant: require('dayjs/locale/zh-tw'),
  };

  locale ? locales[locale] : locales.en;
  dayjs.locale(locale);
};
