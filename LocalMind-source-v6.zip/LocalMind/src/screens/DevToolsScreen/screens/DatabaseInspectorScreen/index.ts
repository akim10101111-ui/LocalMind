export {default} from './DatabaseInspectorScreen';
