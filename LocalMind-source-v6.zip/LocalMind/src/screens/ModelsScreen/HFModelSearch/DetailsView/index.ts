export * from './DetailsView';
