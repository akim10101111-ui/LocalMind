import {Alert, AppState, type AlertButton} from 'react-native';
import {renderHook, act, waitFor} from '@testing-library/react-native';
import {fromByteArray, toByteArray} from 'base64-js';

import AudioRecord from '@fugood/react-native-audio-pcm-stream';

import {useVoiceCapture} from '../useVoiceCapture';
import {asrStore, modelStore, uiStore} from '../../store';
import {
  ASR_MIN_SEGMENT_MS,
  ASR_NO_AUDIO_MS,
  ASR_SAMPLE_RATE,
  energyVad,
  int16PcmToFloat32,
  whisperAsrEngine,
} from '../../services/asr';
import {
  type Signal,
  chunksOf,
  joined,
  mixed,
  overQuietRoom,
  quietRoom,
  quietRoomPcm,
  speechAt,
  toPcm,
} from '../../../jest/fixtures/asr';
import * as micPerm from '../../utils/asrMicPermission';

const mockEnsureMicPermission = jest.spyOn(micPerm, 'ensureMicPermission');
const mockTranscribe = jest.spyOn(whisperAsrEngine, 'transcribe');
const mockCancelTranscription = jest.spyOn(
  whisperAsrEngine,
  'cancelTranscription',
);
const mockRelease = jest.spyOn(whisperAsrEngine, 'release');
const mockAudioInit = AudioRecord.init as jest.Mock;
const mockAudioStart = AudioRecord.start as jest.Mock;
const mockAudioStop = AudioRecord.stop as jest.Mock;
const mockAudioOn = AudioRecord.on as jest.Mock;
const mockAlert = jest.spyOn(Alert, 'alert').mockImplementation(() => {});
const mockMemoryFit = asrStore.captureMemoryFit as jest.Mock;

// Base64-encoded 16-bit PCM: `ms` of a tone at `amplitude`.
function pcmChunkBase64(ms: number, amplitude: number): string {
  const samples = ms * 16; // 16 kHz
  const bytes = new Uint8Array(samples * 2);
  for (let i = 0; i < samples; i++) {
    const v = Math.round(Math.sin((i / 16) * Math.PI) * amplitude * 0x7fff);
    bytes[i * 2] = v & 0xff; // eslint-disable-line no-bitwise
    bytes[i * 2 + 1] = (v >> 8) & 0xff; // eslint-disable-line no-bitwise
  }
  return fromByteArray(bytes);
}

const loudPcmChunkBase64 = () => pcmChunkBase64(1000, 0.3);
const silentPcmChunkBase64 = () => pcmChunkBase64(1000, 0);
const longSpeechPcmBase64 = () => pcmChunkBase64(ASR_MIN_SEGMENT_MS, 0.3);
const said = (text: string, language = 'en') => ({text, language});

// A 500 Hz tone at an RMS level of `dbfs`.
const toneAt = (dbfs: number, ms: number): Signal =>
  Float64Array.from(
    {length: (ms * ASR_SAMPLE_RATE) / 1000},
    (_, i) => Math.SQRT2 * 10 ** (dbfs / 20) * Math.sin((i / 16) * Math.PI),
  );

describe('useVoiceCapture', () => {
  let dataCallback: ((chunk: string) => void) | null = null;

  beforeEach(() => {
    jest.clearAllMocks();
    dataCallback = null;
    asrStore.userASROverride = true;
    asrStore.downloadStates.small = 'ready';
    asrStore.selectedTier = 'small';
    asrStore.captureState = 'idle';
    asrStore.lastError = null;
    asrStore.inputLevels = [];
    asrStore.spokenLanguage = 'en';
    asrStore.waitingForChat = false;
    modelStore.deviceTier = 'flagship';
    modelStore.inferencing = false;
    modelStore.context = undefined;
    asrStore.acceptedCaptureBytes = null;
    mockMemoryFit.mockResolvedValue({status: 'fits', neededBytes: 0});
    mockEnsureMicPermission.mockResolvedValue('granted');
    mockTranscribe.mockResolvedValue(said('hello world'));
    mockCancelTranscription.mockResolvedValue(undefined);
    mockRelease.mockResolvedValue(undefined);
    // Native init() returns void on the JS bridge (the .d.ts is wrong).
    mockAudioInit.mockReturnValue(undefined);
    // Native stop() returns undefined (void), not a Promise — the real contract.
    mockAudioStop.mockReturnValue(undefined);
    mockAudioOn.mockImplementation(
      (_event: string, cb: (c: string) => void) => {
        dataCallback = cb;
        return {remove: jest.fn()};
      },
    );
  });

  async function startRecording(onTranscript = jest.fn()) {
    const hook = renderHook(() => useVoiceCapture({onTranscript}));
    await act(async () => {
      hook.result.current.start();
    });
    await waitFor(() => expect(asrStore.captureState).toBe('recording'));
    return {...hook, onTranscript};
  }

  function feed(pcm: Uint8Array) {
    act(() => {
      chunksOf(pcm).forEach(chunk => dataCallback?.(fromByteArray(chunk)));
    });
  }

  it('records, transcribes on stop, and appends (never sends)', async () => {
    const {result, onTranscript} = await startRecording();

    const chunk = loudPcmChunkBase64();
    act(() => {
      dataCallback?.(chunk);
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() =>
      expect(onTranscript).toHaveBeenCalledWith('hello world'),
    );
    // whisper.rn's transcribeData decodes signed 16-bit PCM, so the captured
    // bytes go through unchanged.
    expect(mockTranscribe).toHaveBeenCalledWith(chunk, {
      tier: 'small',
      language: 'en',
    });
    expect(asrStore.captureState).toBe('idle');
    // The whisper context is freed once transcription settles.
    await waitFor(() => expect(mockRelease).toHaveBeenCalled());
  });

  it('refuses to record when the models need more than total RAM', async () => {
    mockMemoryFit.mockResolvedValue({status: 'wont_fit', neededBytes: 9e9});
    const {result} = renderHook(() =>
      useVoiceCapture({onTranscript: jest.fn()}),
    );

    await act(async () => {
      result.current.start();
    });

    await waitFor(() =>
      expect(asrStore.setError).toHaveBeenCalledWith('insufficient_memory'),
    );
    expect(mockEnsureMicPermission).not.toHaveBeenCalled();
    expect(mockAudioStart).not.toHaveBeenCalled();
    expect(mockAlert).not.toHaveBeenCalled();
  });

  it('records without asking when memory fits', async () => {
    await startRecording();

    expect(mockAlert).not.toHaveBeenCalled();
    expect(asrStore.acceptCaptureMemory).not.toHaveBeenCalled();
  });

  describe('when memory is tight', () => {
    const need = 5e9;

    beforeEach(() => {
      mockMemoryFit.mockResolvedValueOnce({status: 'tight', neededBytes: need});
    });

    async function openAlert() {
      const hook = renderHook(() => useVoiceCapture({onTranscript: jest.fn()}));
      await act(async () => {
        hook.result.current.start();
      });
      await waitFor(() => expect(mockAlert).toHaveBeenCalledTimes(1));
      const buttons = mockAlert.mock.calls[0][2] as AlertButton[];
      return {...hook, buttons};
    }

    it('asks first, with the mic back at rest and no permission prompt', async () => {
      const {buttons} = await openAlert();

      const strings = uiStore.l10n.voiceInput;
      expect(mockAlert).toHaveBeenCalledWith(
        strings.memoryAlertTitle,
        strings.memoryAlertBody,
        expect.any(Array),
        {cancelable: true},
      );
      expect(buttons.map(b => b.text)).toEqual([
        uiStore.l10n.common.cancel,
        strings.memoryAlertTryAnyway,
      ]);
      expect(asrStore.captureState).toBe('idle');
      expect(asrStore.setError).not.toHaveBeenCalled();
      expect(mockEnsureMicPermission).not.toHaveBeenCalled();
    });

    it('Try anyway accepts the need and records after a fresh check', async () => {
      const {buttons} = await openAlert();

      await act(async () => {
        buttons[1].onPress?.();
      });

      expect(asrStore.acceptCaptureMemory).toHaveBeenCalledWith(need);
      await waitFor(() => expect(asrStore.captureState).toBe('recording'));
      expect(mockMemoryFit).toHaveBeenCalledTimes(2);
      expect(mockAudioStart).toHaveBeenCalledTimes(1);
    });

    it('Cancel leaves the mic at rest and accepts nothing', async () => {
      const {buttons} = await openAlert();

      expect(buttons[0].onPress).toBeUndefined();
      expect(asrStore.captureState).toBe('idle');
      expect(asrStore.acceptCaptureMemory).not.toHaveBeenCalled();
    });

    it('a tap after an unanswered alert runs a fresh check and records', async () => {
      const {result} = await openAlert();

      await act(async () => {
        result.current.start();
      });

      await waitFor(() => expect(asrStore.captureState).toBe('recording'));
      expect(mockMemoryFit).toHaveBeenCalledTimes(2);
    });

    it('asks again when the need grew past the one accepted', async () => {
      const {buttons} = await openAlert();
      mockMemoryFit.mockResolvedValueOnce({
        status: 'tight',
        neededBytes: need + 1,
      });

      await act(async () => {
        buttons[1].onPress?.();
      });

      await waitFor(() => expect(mockAlert).toHaveBeenCalledTimes(2));
      expect(asrStore.acceptCaptureMemory).toHaveBeenCalledWith(need);
      expect(asrStore.captureState).toBe('idle');
      expect(mockEnsureMicPermission).not.toHaveBeenCalled();
      expect(mockAudioStart).not.toHaveBeenCalled();
    });

    it('Try anyway on an alert a newer tap replaced does nothing', async () => {
      const {result, buttons: stale} = await openAlert();
      mockMemoryFit.mockResolvedValueOnce({status: 'tight', neededBytes: need});
      await act(async () => {
        result.current.start();
      });
      await waitFor(() => expect(mockAlert).toHaveBeenCalledTimes(2));

      await act(async () => {
        stale[1].onPress?.();
      });

      expect(asrStore.acceptCaptureMemory).not.toHaveBeenCalled();
      expect(mockMemoryFit).toHaveBeenCalledTimes(2);
      expect(mockAudioStart).not.toHaveBeenCalled();
      expect(asrStore.captureState).toBe('idle');

      const current = mockAlert.mock.calls[1][2] as AlertButton[];
      await act(async () => {
        current[1].onPress?.();
      });
      await waitFor(() => expect(asrStore.captureState).toBe('recording'));
      expect(asrStore.acceptCaptureMemory).toHaveBeenCalledTimes(1);
    });

    it('Try anyway after unmount starts nothing', async () => {
      const {buttons, unmount} = await openAlert();

      unmount();
      await act(async () => {
        buttons[1].onPress?.();
      });

      expect(asrStore.acceptCaptureMemory).not.toHaveBeenCalled();
      expect(mockMemoryFit).toHaveBeenCalledTimes(1);
      expect(mockAudioStart).not.toHaveBeenCalled();
      expect(asrStore.captureState).toBe('idle');
    });
  });

  it('detects the spoken language once and reuses it', async () => {
    asrStore.spokenLanguage = null;
    mockTranscribe.mockResolvedValue(said('hallo', 'de'));
    const first = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      first.result.current.stop();
    });
    await waitFor(() => expect(first.onTranscript).toHaveBeenCalled());
    expect(mockTranscribe.mock.calls[0][1]).toEqual({tier: 'small'});
    expect(asrStore.setSpokenLanguage).toHaveBeenCalledWith('de');
    first.unmount();

    const second = await startRecording();
    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      second.result.current.stop();
    });
    await waitFor(() => expect(mockTranscribe).toHaveBeenCalledTimes(2));
    expect(mockTranscribe.mock.calls[1][1]).toEqual({
      tier: 'small',
      language: 'de',
    });
  });

  it('keeps a language reset made while a segment decodes', async () => {
    mockTranscribe.mockImplementation(async () => {
      asrStore.spokenLanguage = null;
      return said('hello world', 'en');
    });
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() => expect(onTranscript).toHaveBeenCalled());
    expect(mockTranscribe.mock.calls[0][1]).toEqual({
      tier: 'small',
      language: 'en',
    });
    expect(asrStore.setSpokenLanguage).not.toHaveBeenCalled();
  });

  it('keeps detecting while transcripts come back empty', async () => {
    asrStore.spokenLanguage = null;
    mockTranscribe.mockResolvedValue(said('', 'ja'));
    const {result} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() => expect(mockRelease).toHaveBeenCalled());
    expect(asrStore.setSpokenLanguage).not.toHaveBeenCalled();
  });

  describe('saving the detected language', () => {
    const segmentVad = () =>
      energyVad(
        int16PcmToFloat32(toByteArray(mockTranscribe.mock.calls[0][0])),
      );

    beforeEach(() => {
      asrStore.spokenLanguage = null;
      mockTranscribe.mockResolvedValue(said('hallo', 'de'));
    });

    async function dictate(signal: Signal) {
      const {result, onTranscript} = await startRecording();
      feed(toPcm(signal));
      await act(async () => {
        result.current.stop();
      });
      await waitFor(() => expect(onTranscript).toHaveBeenCalledWith('hallo'));
    }

    it('does not save it from quiet speech the -40 dBFS floor would not pass', async () => {
      await dictate(overQuietRoom(speechAt(-46)));

      expect(segmentVad().voicedMs).toBe(0);
      expect(asrStore.setSpokenLanguage).not.toHaveBeenCalled();
    });

    it.each([
      [240, false],
      [360, true],
    ])(
      'with a %d ms burst at -30 dBFS in the quiet speech, saves it: %s',
      async (burstMs, saves) => {
        await dictate(
          joined(
            overQuietRoom(speechAt(-46)),
            mixed(quietRoom(1000), toneAt(-30, burstMs), 300),
          ),
        );

        expect(segmentVad().passed).toBe(saves);
        if (saves) {
          expect(asrStore.setSpokenLanguage).toHaveBeenCalledWith('de');
        } else {
          expect(asrStore.setSpokenLanguage).not.toHaveBeenCalled();
        }
      },
    );
  });

  it('waits for a chat reply on the CPU before transcribing', async () => {
    modelStore.inferencing = true;
    modelStore.context = {gpu: false} as any;
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() => expect(asrStore.waitingForChat).toBe(true));
    expect(asrStore.captureState).toBe('transcribing');
    expect(mockTranscribe).not.toHaveBeenCalled();

    act(() => {
      modelStore.inferencing = false;
    });

    await waitFor(() =>
      expect(onTranscript).toHaveBeenCalledWith('hello world'),
    );
    expect(asrStore.waitingForChat).toBe(false);
  });

  it('transcribes right away while a chat reply runs on the GPU', async () => {
    modelStore.inferencing = true;
    modelStore.context = {gpu: true} as any;
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() =>
      expect(onTranscript).toHaveBeenCalledWith('hello world'),
    );
    expect(asrStore.setWaitingForChat).not.toHaveBeenCalled();
  });

  it('drops the capture on cancel while waiting for the chat reply', async () => {
    modelStore.inferencing = true;
    modelStore.context = {gpu: false} as any;
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });
    await waitFor(() => expect(asrStore.waitingForChat).toBe(true));

    act(() => {
      result.current.cancel();
    });
    act(() => {
      modelStore.inferencing = false;
    });

    await waitFor(() => expect(mockRelease).toHaveBeenCalled());
    expect(asrStore.captureState).toBe('idle');
    expect(asrStore.waitingForChat).toBe(false);
    expect(mockTranscribe).not.toHaveBeenCalled();
    expect(onTranscript).not.toHaveBeenCalled();
  });

  it('transcribes at a pause while still recording, with earlier text as context', async () => {
    mockTranscribe
      .mockResolvedValueOnce(said('first part'))
      .mockResolvedValueOnce(said('second part'));
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(longSpeechPcmBase64());
      dataCallback?.(silentPcmChunkBase64());
    });
    await waitFor(() => expect(mockTranscribe).toHaveBeenCalledTimes(1));
    expect(asrStore.captureState).toBe('recording');
    expect(mockTranscribe.mock.calls[0][1]).toEqual({
      tier: 'small',
      language: 'en',
      prompt: undefined,
    });

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() =>
      expect(onTranscript).toHaveBeenCalledWith('first part second part'),
    );
    expect(mockTranscribe).toHaveBeenCalledTimes(2);
    expect(mockTranscribe.mock.calls[1][1]).toEqual({
      tier: 'small',
      language: 'en',
      prompt: 'first part',
    });
    await waitFor(() => expect(mockRelease).toHaveBeenCalled());
  });

  it('keeps the segments that transcribed when one fails, with a notice', async () => {
    mockTranscribe.mockRejectedValueOnce(new Error('decode failed'));
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(longSpeechPcmBase64());
      dataCallback?.(silentPcmChunkBase64());
    });
    await waitFor(() => expect(mockTranscribe).toHaveBeenCalledTimes(1));
    expect(asrStore.setError).not.toHaveBeenCalled();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() =>
      expect(onTranscript).toHaveBeenCalledWith('hello world'),
    );
    expect(mockTranscribe).toHaveBeenCalledTimes(2);
    expect(asrStore.setError).toHaveBeenCalledWith('transcript_partial');
  });

  it('releases the model on cancel', async () => {
    const {result} = await startRecording();

    act(() => {
      result.current.cancel();
    });

    await waitFor(() => expect(mockRelease).toHaveBeenCalled());
  });

  it('publishes the peak loudness of every two captured chunks', async () => {
    await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    expect(asrStore.pushInputLevel).not.toHaveBeenCalled();
    act(() => {
      dataCallback?.(silentPcmChunkBase64());
    });

    expect(asrStore.pushInputLevel).toHaveBeenCalledTimes(1);
    const level = (asrStore.pushInputLevel as jest.Mock).mock.calls[0][0];
    expect(level).toBeGreaterThan(0.5);
    expect(level).toBeLessThanOrEqual(1);
  });

  it('returns to idle without an error or decode on a silent capture', async () => {
    const {result, onTranscript} = await startRecording();

    // No audio chunks → nothing voiced.
    await act(async () => {
      result.current.stop();
    });

    expect(asrStore.captureState).toBe('idle');
    expect(asrStore.setError).not.toHaveBeenCalled();
    expect(mockTranscribe).not.toHaveBeenCalled();
    expect(onTranscript).not.toHaveBeenCalled();
  });

  describe('real speech at quiet microphone levels', () => {
    const tallestBar = () => Math.max(0, ...asrStore.inputLevels);

    // Android's CDD sets VOICE_RECOGNITION so a 90 dB SPL tone reads about
    // -22 dBFS, with no gain control: -40 dBFS is speech at about 72 dB SPL at
    // the microphone, -44 about 68 and -46 about 66.
    it.each([-40, -44, -46])(
      'decodes a short phrase spoken at %d dBFS that the waveform draws',
      async dbfs => {
        const {result, onTranscript} = await startRecording();

        feed(toPcm(speechAt(dbfs)));
        expect(tallestBar()).toBeGreaterThan(0.35);
        await act(async () => {
          result.current.stop();
        });

        await waitFor(() =>
          expect(onTranscript).toHaveBeenCalledWith('hello world'),
        );
        expect(mockTranscribe).toHaveBeenCalledTimes(1);
      },
    );
  });

  describe('when a dictation ends with no text', () => {
    const stop = async (result: {current: {stop: () => void}}) => {
      await act(async () => {
        result.current.stop();
      });
    };

    it('closes silently after a quiet room, without decoding it', async () => {
      const {result, onTranscript} = await startRecording();

      feed(quietRoomPcm());
      await stop(result);

      await waitFor(() => expect(mockRelease).toHaveBeenCalled());
      expect(asrStore.captureState).toBe('idle');
      expect(asrStore.setError).not.toHaveBeenCalled();
      expect(mockTranscribe).not.toHaveBeenCalled();
      expect(onTranscript).not.toHaveBeenCalled();
    });

    it('closes silently when speech decodes to no words', async () => {
      mockTranscribe.mockResolvedValue(said(''));
      const {result, onTranscript} = await startRecording();

      feed(toPcm(speechAt(-30)));
      await stop(result);

      await waitFor(() => expect(mockRelease).toHaveBeenCalled());
      expect(asrStore.captureState).toBe('idle');
      expect(asrStore.setError).not.toHaveBeenCalled();
      expect(mockTranscribe).toHaveBeenCalledTimes(1);
      expect(onTranscript).not.toHaveBeenCalled();
    });

    it('closes silently on a stop within a second', async () => {
      const {result, onTranscript} = await startRecording();

      feed(quietRoomPcm().subarray(0, 950 * 32));
      await stop(result);

      await waitFor(() => expect(mockRelease).toHaveBeenCalled());
      expect(asrStore.captureState).toBe('idle');
      expect(asrStore.setError).not.toHaveBeenCalled();
      expect(onTranscript).not.toHaveBeenCalled();
    });

    it('stays silent on cancel', async () => {
      const {result, onTranscript} = await startRecording();

      feed(quietRoomPcm());
      act(() => {
        result.current.cancel();
      });
      await stop(result);

      expect(asrStore.captureState).toBe('idle');
      expect(asrStore.setError).not.toHaveBeenCalled();
      expect(onTranscript).not.toHaveBeenCalled();
    });
  });

  describe('when the microphone delivers nothing', () => {
    beforeEach(() => {
      jest.useFakeTimers();
    });

    afterEach(() => {
      jest.useRealTimers();
    });

    it('reports mic_unavailable and releases capture', async () => {
      await startRecording();

      act(() => {
        jest.advanceTimersByTime(ASR_NO_AUDIO_MS);
      });

      expect(asrStore.setError).toHaveBeenCalledWith('mic_unavailable');
      expect(mockAudioStop).toHaveBeenCalled();
    });

    it('stays quiet once silent audio arrives', async () => {
      await startRecording();

      act(() => {
        dataCallback?.(silentPcmChunkBase64());
        jest.advanceTimersByTime(ASR_NO_AUDIO_MS);
      });

      expect(asrStore.setError).not.toHaveBeenCalled();
      expect(asrStore.captureState).toBe('recording');
    });
  });

  it('returns to idle without an error on an empty transcript', async () => {
    mockTranscribe.mockResolvedValue(said(''));
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() => expect(mockRelease).toHaveBeenCalled());
    expect(asrStore.captureState).toBe('idle');
    expect(asrStore.setError).not.toHaveBeenCalled();
    expect(onTranscript).not.toHaveBeenCalled();
  });

  it('discards the capture on cancel while recording', async () => {
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    mockAudioStop.mockClear();
    act(() => {
      result.current.cancel();
    });

    expect(mockAudioStop).toHaveBeenCalled();
    expect(asrStore.captureState).toBe('idle');
    // A stop after cancel finds no capture to transcribe.
    await act(async () => {
      result.current.stop();
    });
    expect(mockTranscribe).not.toHaveBeenCalled();
    expect(onTranscript).not.toHaveBeenCalled();
  });

  it('stops whisper and drops the transcript on cancel while transcribing', async () => {
    let resolveTranscribe:
      | ((transcript: ReturnType<typeof said>) => void)
      | null = null;
    mockTranscribe.mockImplementation(
      () =>
        new Promise(resolve => {
          resolveTranscribe = resolve;
        }),
    );
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });
    expect(asrStore.captureState).toBe('transcribing');

    act(() => {
      result.current.cancel();
    });
    expect(mockCancelTranscription).toHaveBeenCalled();
    expect(asrStore.captureState).toBe('idle');

    await act(async () => {
      resolveTranscribe?.(said('too late'));
    });
    expect(onTranscript).not.toHaveBeenCalled();
    expect(asrStore.captureState).toBe('idle');
  });

  it('does not record when cancelled while the permission prompt is open', async () => {
    let resolvePerm: ((r: 'granted') => void) | null = null;
    mockEnsureMicPermission.mockImplementation(
      () =>
        new Promise<'granted'>(resolve => {
          resolvePerm = resolve;
        }),
    );
    const {result} = renderHook(() =>
      useVoiceCapture({onTranscript: jest.fn()}),
    );

    await act(async () => {
      result.current.start();
    });
    act(() => {
      result.current.cancel();
    });
    await act(async () => {
      resolvePerm?.('granted');
    });

    expect(mockAudioStart).not.toHaveBeenCalled();
    expect(asrStore.captureState).toBe('idle');
  });

  it('routes to error and never records when permission is denied', async () => {
    mockEnsureMicPermission.mockResolvedValue('denied');
    const onTranscript = jest.fn();
    const {result} = renderHook(() => useVoiceCapture({onTranscript}));

    await act(async () => {
      result.current.start();
    });

    await waitFor(() =>
      expect(asrStore.setError).toHaveBeenCalledWith('permission_denied'),
    );
    expect(mockAudioStart).not.toHaveBeenCalled();
  });

  it('maps a blocked permission to permission_blocked', async () => {
    mockEnsureMicPermission.mockResolvedValue('blocked');
    const {result} = renderHook(() =>
      useVoiceCapture({onTranscript: jest.fn()}),
    );

    await act(async () => {
      result.current.start();
    });

    await waitFor(() =>
      expect(asrStore.setError).toHaveBeenCalledWith('permission_blocked'),
    );
    expect(mockAudioStart).not.toHaveBeenCalled();
  });

  it('does not start capture when the gate is closed', async () => {
    asrStore.userASROverride = false;
    const {result} = renderHook(() =>
      useVoiceCapture({onTranscript: jest.fn()}),
    );

    await act(async () => {
      result.current.start();
    });

    expect(mockEnsureMicPermission).not.toHaveBeenCalled();
  });

  it('ignores a re-entrant start while recording', async () => {
    const {result} = await startRecording();
    const startCalls = mockAudioStart.mock.calls.length;
    const onCalls = mockAudioOn.mock.calls.length;

    await act(async () => {
      result.current.start();
    });

    expect(mockAudioStart.mock.calls.length).toBe(startCalls);
    expect(mockAudioOn.mock.calls.length).toBe(onCalls);
  });

  it('re-arms and records on a start right after an error', async () => {
    mockEnsureMicPermission.mockResolvedValueOnce('denied');
    const {result} = renderHook(() =>
      useVoiceCapture({onTranscript: jest.fn()}),
    );

    await act(async () => {
      result.current.start();
    });
    await waitFor(() => expect(asrStore.captureState).toBe('error'));

    await act(async () => {
      result.current.start();
    });

    await waitFor(() => expect(asrStore.captureState).toBe('recording'));
    expect(mockAudioStart).toHaveBeenCalled();
  });

  it('aborts cleanly when audio init rejects', async () => {
    mockAudioInit.mockRejectedValueOnce(new Error('init failed'));
    const {result} = renderHook(() =>
      useVoiceCapture({onTranscript: jest.fn()}),
    );

    await act(async () => {
      result.current.start();
    });

    await waitFor(() =>
      expect(asrStore.setError).toHaveBeenCalledWith('transcribe_failed'),
    );
    expect(mockAudioStart).not.toHaveBeenCalled();
  });

  it('surfaces a transcription failure', async () => {
    mockTranscribe.mockRejectedValueOnce(new Error('decode failed'));
    const {result, onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });

    await waitFor(() =>
      expect(asrStore.setError).toHaveBeenCalledWith('transcribe_failed'),
    );
    expect(onTranscript).not.toHaveBeenCalled();
  });

  it('finishes the capture when the app goes to the background', async () => {
    let appStateHandler: ((s: string) => void) | null = null;
    jest
      .spyOn(AppState, 'addEventListener')
      .mockImplementationOnce((_type, handler) => {
        appStateHandler = handler as (s: string) => void;
        return {remove: jest.fn()} as any;
      });
    const {onTranscript} = await startRecording();

    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    mockAudioStop.mockClear();
    act(() => {
      appStateHandler?.('background');
    });

    expect(mockAudioStop).toHaveBeenCalled();
    await waitFor(() =>
      expect(onTranscript).toHaveBeenCalledWith('hello world'),
    );
    expect(asrStore.captureState).toBe('idle');
  });

  it('releases native capture on unmount', async () => {
    const {unmount} = await startRecording();
    mockAudioStop.mockClear();

    unmount();
    expect(mockAudioStop).toHaveBeenCalled();
  });

  it('unmount during the permission prompt rests the mic and never records', async () => {
    let resolvePerm: ((r: 'granted') => void) | null = null;
    mockEnsureMicPermission.mockImplementation(
      () =>
        new Promise<'granted'>(resolve => {
          resolvePerm = resolve;
        }),
    );
    const {result, unmount} = renderHook(() =>
      useVoiceCapture({onTranscript: jest.fn()}),
    );
    await act(async () => {
      result.current.start();
    });
    expect(asrStore.captureState).toBe('requesting_perm');

    unmount();
    expect(asrStore.resetCapture).toHaveBeenCalled();
    await act(async () => {
      resolvePerm?.('granted');
    });

    expect(mockAudioStart).not.toHaveBeenCalled();
    expect(asrStore.captureState).toBe('idle');
  });

  it('unmount during the memory check starts nothing', async () => {
    let resolveFit:
      | ((fit: {status: 'tight'; neededBytes: number}) => void)
      | null = null;
    mockMemoryFit.mockImplementation(
      () =>
        new Promise(resolve => {
          resolveFit = resolve;
        }),
    );
    const {result, unmount} = renderHook(() =>
      useVoiceCapture({onTranscript: jest.fn()}),
    );
    await act(async () => {
      result.current.start();
    });

    unmount();
    await act(async () => {
      resolveFit?.({status: 'tight', neededBytes: 5e9});
    });

    expect(mockAlert).not.toHaveBeenCalled();
    expect(mockEnsureMicPermission).not.toHaveBeenCalled();
    expect(asrStore.captureState).toBe('idle');
  });

  it('unmount while transcribing stops whisper and rests the mic', async () => {
    mockTranscribe.mockImplementation(() => new Promise(() => {}));
    const {result, unmount} = await startRecording();
    act(() => {
      dataCallback?.(loudPcmChunkBase64());
    });
    await act(async () => {
      result.current.stop();
    });
    expect(asrStore.captureState).toBe('transcribing');

    unmount();

    expect(mockCancelTranscription).toHaveBeenCalled();
    expect(asrStore.captureState).toBe('idle');
  });

  it("unmounting another instance leaves this one's capture alone", async () => {
    const other = renderHook(() => useVoiceCapture({onTranscript: jest.fn()}));
    await startRecording();

    other.unmount();

    expect(asrStore.resetCapture).not.toHaveBeenCalled();
    expect(asrStore.captureState).toBe('recording');
  });

  it('an instance whose capture ended does not cancel a newer one on unmount', async () => {
    const first = await startRecording();
    act(() => {
      first.result.current.cancel();
    });
    await startRecording();
    (asrStore.resetCapture as jest.Mock).mockClear();

    first.unmount();

    expect(asrStore.resetCapture).not.toHaveBeenCalled();
    expect(asrStore.captureState).toBe('recording');
  });
});
