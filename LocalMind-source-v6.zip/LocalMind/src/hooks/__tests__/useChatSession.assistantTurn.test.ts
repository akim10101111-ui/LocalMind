import {LlamaContext} from 'llama.rn';
import {renderHook, act} from '@testing-library/react-native';

import {textMessage} from '../../../jest/fixtures';
import {sessionFixtures} from '../../../jest/fixtures/chatSessions';
import {
  mockLlamaContextParams,
  modelsList,
} from '../../../jest/fixtures/models';

import {useChatSession} from '../useChatSession';
import {chatSessionStore, modelStore, palStore, serverStore} from '../../store';
import {resolveBannerVariant} from '../../utils/bannerVariantResolver';
import {ModelOrigin} from '../../utils/types';
import {assistant} from '../../utils/chat';
import {talentRegistry} from '../../services/talents';
import type {MessageType} from '../../utils/types';
import type {TalentEngine, TalentResult} from '../../services/talents/types';

const mockAssistant = {id: 'h3o3lc5xj'};

beforeEach(() => {
  jest.clearAllMocks();

  palStore.pals = [] as any;
  chatSessionStore.sessions = sessionFixtures as any;
  chatSessionStore.activeSessionId = 'session-1';
  chatSessionStore.agentUiState = {
    status: 'idle',
    pendingTalentNames: [],
    hitMaxTurns: false,
  };

  modelStore.models = modelsList as any;
  modelStore.activeModelId = undefined;
  modelStore.context = new LlamaContext(mockLlamaContextParams);
  modelStore.engine = {
    completion: jest.fn((params, onData) =>
      modelStore.context!.completion(params, onData),
    ),
    stopCompletion: jest.fn(async () => {
      await modelStore.context?.stopCompletion();
    }),
  };
});

const applyChatTemplateSpy = jest
  .spyOn(require('../../utils/chat'), 'applyChatTemplate')
  .mockImplementation(async () => 'mocked prompt');

describe('useChatSession — AssistantTurn integration', () => {
  beforeEach(() => {
    applyChatTemplateSpy.mockClear();
  });

  it('#1 happy path: writes per-step content via updateActiveStepStreaming and finalizes the step', async () => {
    if (modelStore.context) {
      modelStore.context.completion = jest
        .fn()
        .mockImplementation(async (_params, onData) => {
          onData?.({content: 'Hello'});
          onData?.({content: ' there'});
          return {
            text: 'Hello there',
            content: 'Hello there',
            timings: {predicted_per_second: 100},
          };
        });
    }
    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    // The hook adds the user message AND the empty assistant turn.
    expect(chatSessionStore.addMessageToCurrentSession).toHaveBeenCalled();
    // The empty assistant turn is added WITHOUT metadata.copyable so
    // the turn footer's copy button stays hidden during streaming.
    // copyable is set later at run_finished (asserted below) or at the
    // abort catch path.
    const addAssistantCall = (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mock.calls.find(args => args[0]?.type === 'assistant_turn');
    expect(addAssistantCall).toBeDefined();
    expect(addAssistantCall![0].metadata.copyable).toBeUndefined();
    // pushAgentStep called for each step_started — one in this happy path.
    expect(chatSessionStore.pushAgentStep).toHaveBeenCalled();
    // Per-token writes go through updateActiveStepStreaming.
    expect(chatSessionStore.updateActiveStepStreaming).toHaveBeenCalled();
    // step_finished triggers finalizeActiveStep.
    expect(chatSessionStore.finalizeActiveStep).toHaveBeenCalled();
    // run_finished writes timings.
    expect(chatSessionStore.updateMessage).toHaveBeenCalledWith(
      expect.any(String),
      expect.any(String),
      expect.objectContaining({
        metadata: expect.objectContaining({
          timings: expect.any(Object),
          copyable: true,
        }),
      }),
    );
  });

  it('#2 run_finished with hitMaxTurns:true → metadata.hitMaxTurns written, console.warn emitted, no run_failed surfacing', async () => {
    // Engine always returns tool_calls, never a final answer — exhausts maxTurns.
    if (modelStore.context) {
      modelStore.context.completion = jest
        .fn()
        .mockImplementation(async () => ({
          text: '',
          content: '',
          tool_calls: [
            {
              id: 'c0',
              type: 'function',
              function: {name: 'unused', arguments: '{}'},
            },
          ],
        }));
    }
    const warnSpy = jest.spyOn(console, 'warn').mockImplementation(() => {});

    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    // hitMaxTurns metadata landed.
    const calls = (chatSessionStore.updateMessage as jest.Mock).mock.calls;
    const hitMaxCall = calls.find(c => c[2]?.metadata?.hitMaxTurns === true);
    expect(hitMaxCall).toBeDefined();
    // Observability log.
    expect(warnSpy).toHaveBeenCalledWith(
      expect.stringContaining('hit maxTurns'),
    );
    warnSpy.mockRestore();
  });

  it('#3 run_failed: error rollback writes {interrupted, copyable} into assistant_turn metadata (does not lose steps)', async () => {
    // Engine throws — runner emits run_failed. Silence the expected
    // console.error so the test output stays clean.
    const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    if (modelStore.context) {
      modelStore.context.completion = jest
        .fn()
        .mockRejectedValueOnce(new Error('boom'));
    }
    const ref: {
      current: {createdAt: number; id: string; sessionId: string} | null;
    } = {current: null};
    const {result} = renderHook(() =>
      useChatSession(ref, textMessage.author, mockAssistant),
    );

    // Seed a session with an assistant_turn carrying partial step state so
    // the rollback path takes the "preserve metadata" branch.
    const turnId = 'turn-rollback-test';
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [
          {
            id: turnId,
            type: 'assistant_turn',
            author: assistant,
            createdAt: Date.now(),
            steps: [{content: 'partial'}],
            metadata: {copyable: true},
          } as MessageType.AssistantTurn,
        ],
        completionSettings: {},
        settingsSource: 'pal',
      },
    ] as any;
    // The hook's prepareCompletion creates a fresh assistant turn with an
    // empty steps[] array; we want the test to verify the rollback path
    // when the runner errors — addMessageToCurrentSession is mocked to
    // inject the seeded id.
    (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mockImplementation(async (msg: any) => {
      msg.id = turnId;
    });

    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    // Rollback path: updateMessage called with {interrupted: true,
    // copyable: true}. Seed includes partial step content so the
    // preserve branch (not the delete-empty branch) must run.
    const updateMessageCalls = (chatSessionStore.updateMessage as jest.Mock)
      .mock.calls;
    const interruptedCall = updateMessageCalls.find(
      c => c[2]?.metadata?.interrupted === true,
    );
    expect(interruptedCall).toBeDefined();
    expect(interruptedCall![2].metadata.copyable).toBe(true);
    // Generic engine failure (not a tool-arg parse error), so
    // truncationLikely should NOT be set.
    expect(interruptedCall![2].metadata.truncationLikely).toBeUndefined();
    // When the turn carries the failure context via its own metadata,
    // the legacy `Completion failed: …` system-message dump is
    // suppressed to avoid duplicating the same signal in two places.
    const sysCall = (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mock.calls.find(c => c[0]?.metadata?.system === true);
    expect(sysCall).toBeUndefined();

    errSpy.mockRestore();
  });

  it('#3b run_failed with tool-args parse error → metadata.truncationLikely set; no system message', async () => {
    // llama.cpp's native tool-call parser throws when the model emits
    // a malformed tool_calls arguments string — typically because it
    // ran out of context mid-args (very common for `render_html` with
    // long HTML). The catch block detects this shape and writes
    // {truncationLikely: true} on the turn so the footer can surface
    // a more actionable hint instead of dumping the multi-KB native
    // error string into chat.
    const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    if (modelStore.context) {
      modelStore.context.completion = jest
        .fn()
        .mockRejectedValueOnce(
          new Error(
            'Failed to parse tool call arguments as JSON: [json.exception.parse_error.101] parse error',
          ),
        );
    }
    const ref: {
      current: {createdAt: number; id: string; sessionId: string} | null;
    } = {current: null};
    const {result} = renderHook(() =>
      useChatSession(ref, textMessage.author, mockAssistant),
    );

    const turnId = 'turn-truncation-test';
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [
          {
            id: turnId,
            type: 'assistant_turn',
            author: assistant,
            createdAt: Date.now(),
            steps: [{content: 'partial'}],
            metadata: {copyable: true},
          } as MessageType.AssistantTurn,
        ],
        completionSettings: {},
        settingsSource: 'pal',
      },
    ] as any;
    (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mockImplementation(async (msg: any) => {
      msg.id = turnId;
    });

    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    const updateMessageCalls = (chatSessionStore.updateMessage as jest.Mock)
      .mock.calls;
    const interruptedCall = updateMessageCalls.find(
      c => c[2]?.metadata?.interrupted === true,
    );
    expect(interruptedCall).toBeDefined();
    expect(interruptedCall![2].metadata.truncationLikely).toBe(true);
    expect(interruptedCall![2].metadata.copyable).toBe(true);

    const sysCall = (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mock.calls.find(c => c[0]?.metadata?.system === true);
    expect(sysCall).toBeUndefined();

    errSpy.mockRestore();
  });

  it('#3c prompt overflow ("Context is full") with no content → records contextFull snapshot, no error dump', async () => {
    // When the prompt itself exceeds n_ctx (ctx_shift off, the llama.rn
    // default), the native layer throws "Context is full" before any token,
    // so it never reaches run_finished and the turn has no content. The catch
    // path must still record a contextFull snapshot so the banner surfaces,
    // instead of dumping the raw native error.
    const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    if (modelStore.context) {
      modelStore.context.completion = jest
        .fn()
        .mockRejectedValueOnce(new Error('Context is full'));
    }
    const ref: {
      current: {createdAt: number; id: string; sessionId: string} | null;
    } = {current: null};
    const {result} = renderHook(() =>
      useChatSession(ref, textMessage.author, mockAssistant),
    );

    const turnId = 'turn-context-full-test';
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [
          {
            id: turnId,
            type: 'assistant_turn',
            author: assistant,
            createdAt: Date.now(),
            steps: [], // no generated content — prompt overflowed
            metadata: {copyable: true},
          } as MessageType.AssistantTurn,
        ],
        completionSettings: {},
        settingsSource: 'pal',
      },
    ] as any;
    (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mockImplementation(async (msg: any) => {
      msg.id = turnId;
    });

    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    // A contextFull snapshot is recorded so the banner can surface.
    const snapCall = (
      chatSessionStore.recordCompletionSnapshot as jest.Mock
    ).mock.calls.find(c => c[0]?.contextFull === true);
    expect(snapCall).toBeDefined();

    // No raw "Completion failed: …" system-message dump.
    const sysCall = (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mock.calls.find(c => c[0]?.metadata?.system === true);
    expect(sysCall).toBeUndefined();

    errSpy.mockRestore();
  });

  it('#3d "Context is full" WITH partial content → turn tagged contextFull (no truncationLikely)', async () => {
    // Defensive branch: if a context-full error arrives after some content
    // was produced, the partial turn is preserved and tagged contextFull via
    // treatAsContextFull — but without truncationLikely (that flag is reserved
    // for the tool-args parse case).
    const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    if (modelStore.context) {
      modelStore.context.completion = jest
        .fn()
        .mockRejectedValueOnce(new Error('Context is full'));
    }
    const ref: {
      current: {createdAt: number; id: string; sessionId: string} | null;
    } = {current: null};
    const {result} = renderHook(() =>
      useChatSession(ref, textMessage.author, mockAssistant),
    );

    const turnId = 'turn-context-full-partial-test';
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [
          {
            id: turnId,
            type: 'assistant_turn',
            author: assistant,
            createdAt: Date.now(),
            steps: [{content: 'partial'}],
            metadata: {copyable: true},
          } as MessageType.AssistantTurn,
        ],
        completionSettings: {},
        settingsSource: 'pal',
      },
    ] as any;
    (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mockImplementation(async (msg: any) => {
      msg.id = turnId;
    });

    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    const interruptedCall = (
      chatSessionStore.updateMessage as jest.Mock
    ).mock.calls.find(c => c[2]?.metadata?.interrupted === true);
    expect(interruptedCall).toBeDefined();
    expect(interruptedCall![2].metadata.completionResult?.contextFull).toBe(
      true,
    );
    expect(interruptedCall![2].metadata.truncationLikely).toBeUndefined();

    errSpy.mockRestore();
  });

  it('#hookTest1 multi-step run with tool_call_finished: appendToolOutcome called for the active step', async () => {
    // Wire a fake talent into the registry so the runner's executeOne()
    // path finds it. Restore at end so other tests are not affected.
    const fakeTalent: TalentEngine = {
      name: 'calculate',
      execute: async () => ({type: 'text', summary: '4'}) as TalentResult,
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'calculate', description: '', parameters: {}},
      }),
    };
    talentRegistry.register(fakeTalent);
    // Pal advertises calculate so allowedTalentNames includes it.
    palStore.pals = [
      {
        id: 'pal-1',
        type: 'local',
        name: 'Calc Pal',
        systemPrompt: '',
        parameters: {},
        parameterSchema: [],
        isSystemPromptChanged: false,
        useAIPrompt: false,
        source: 'local',
        pact: {talents: [{name: 'calculate', necessity: 'optional'}]},
      } as any,
    ];
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [],
        completionSettings: {},
        settingsSource: 'pal',
        activePalId: 'pal-1',
      } as any,
    ];
    chatSessionStore.activeSessionId = 'session-1';

    let turnIndex = 0;
    if (modelStore.context) {
      modelStore.context.completion = jest.fn().mockImplementation(async () => {
        turnIndex += 1;
        if (turnIndex === 1) {
          return {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'calculate', arguments: '{"e":"2+2"}'},
              },
            ],
          };
        }
        return {text: '4', content: '4'};
      });
    }

    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    // appendToolOutcome fired with the calculate outcome.
    const calls = (chatSessionStore.appendToolOutcome as jest.Mock).mock.calls;
    expect(calls.length).toBeGreaterThanOrEqual(1);
    const outcomeCall = calls.find(c => c[2]?.toolName === 'calculate');
    expect(outcomeCall).toBeDefined();
    expect(outcomeCall![2].responseContent).toBe('4');

    // Cleanup: remove the test talent so other tests aren't affected.
    (talentRegistry as any).engines.delete('calculate');
  });

  it('#hookTest2 tool turn: appendToolCall lands ids that match the upcoming appendToolOutcome callId by construction (per-frame id-match invariant)', async () => {
    // The runner attaches its normalized toolCalls to step_finished;
    // the hook calls appendToolCall with that list before
    // appendToolOutcome fires for each call. Invariant: at every
    // render frame, step.toolCalls[i].id === outcome.callId (vacuously
    // true while outcomes lag the calls; strictly enforced as soon as
    // both are present). This test verifies the invariant by
    // intercepting both writers and checking the call-order produces
    // matching ids.
    const fakeTalent: TalentEngine = {
      name: 'calculate',
      execute: async () => ({type: 'text', summary: '4'}) as TalentResult,
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'calculate', description: '', parameters: {}},
      }),
    };
    talentRegistry.register(fakeTalent);
    palStore.pals = [
      {
        id: 'pal-1',
        type: 'local',
        name: 'Calc Pal',
        systemPrompt: '',
        parameters: {},
        parameterSchema: [],
        isSystemPromptChanged: false,
        useAIPrompt: false,
        source: 'local',
        pact: {talents: [{name: 'calculate', necessity: 'optional'}]},
      } as any,
    ];
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [],
        completionSettings: {},
        settingsSource: 'pal',
        activePalId: 'pal-1',
      } as any,
    ];
    chatSessionStore.activeSessionId = 'session-1';

    let turnIndex = 0;
    if (modelStore.context) {
      modelStore.context.completion = jest.fn().mockImplementation(async () => {
        turnIndex += 1;
        if (turnIndex === 1) {
          return {
            text: '',
            content: '',
            tool_calls: [
              {
                // Empty id from llama.rn — the runner reconciles via
                // normalizeToolCallIds. The hook MUST receive the
                // normalized id, not this raw one.
                id: '',
                type: 'function',
                function: {name: 'calculate', arguments: '{"e":"2+2"}'},
              },
            ],
          };
        }
        return {text: '4', content: '4'};
      });
    }

    const appendToolCallSpy = chatSessionStore.appendToolCall as jest.Mock;
    const appendToolOutcomeSpy =
      chatSessionStore.appendToolOutcome as jest.Mock;

    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    expect(appendToolCallSpy).toHaveBeenCalled();
    expect(appendToolOutcomeSpy).toHaveBeenCalled();

    // For every appendToolCall invocation, every call.id MUST match a
    // subsequently-appended outcome.callId (within the same step).
    // The invariant: step.toolCalls[i].id === outcome.callId by
    // construction.
    const callsArgs = appendToolCallSpy.mock.calls;
    const outcomeArgs = appendToolOutcomeSpy.mock.calls;
    const calledIds = callsArgs.flatMap(c =>
      (c[2] as Array<{id: string}>).map(x => x.id),
    );
    const outcomeCallIds = outcomeArgs.map(
      c => (c[2] as {callId: string}).callId,
    );
    // No empty ids emitted — runner normalized them.
    expect(calledIds.every(id => id.length > 0)).toBe(true);
    // Every outcome's callId must appear in the appendToolCall set.
    for (const cid of outcomeCallIds) {
      expect(calledIds).toContain(cid);
    }

    // Cleanup
    (talentRegistry as any).engines.delete('calculate');
  });

  it('handleStopPress aborts the in-flight runner before stopCompletion fires', async () => {
    let resolveCompletion: (v: any) => void;
    const completionPromise = new Promise(resolve => {
      resolveCompletion = resolve;
    });
    if (modelStore.context) {
      modelStore.context.completion = jest
        .fn()
        .mockImplementation(() => completionPromise);
    }
    modelStore.setInferencing(true);

    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    // Fire-and-forget the send so handleStopPress can interrupt it.
    const sendPromise = result.current.handleSendPress(textMessage);
    // Allow microtasks to run so the engine.completion() call is in
    // flight before we press stop.
    await act(async () => {
      await Promise.resolve();
    });

    await act(async () => {
      await result.current.handleStopPress();
    });

    expect(modelStore.engine?.stopCompletion).toHaveBeenCalled();

    // Resolve the pending completion so the awaiting handleSendPress
    // can finish and we don't leak an open promise.
    resolveCompletion!({
      text: 'cancelled',
      content: 'cancelled',
    });
    await act(async () => {
      await sendPromise;
    });
  });

  // ---------- Per-frame id-match invariant under multi-tool /
  // multi-step / abort variations. hookTest2 covers the single-tool
  // case; these add coverage for the remaining shapes. ----------

  it('#hookTest3 multi-tool turn: appendToolCall lands TWO normalized ids before two appendToolOutcome calls (per-frame id-match holds across tools)', async () => {
    // Both tools succeed. The runner emits one step_finished with
    // toolCalls.length === 2; the hook calls appendToolCall once with
    // both, then appendToolOutcome twice (one per tool). The ids
    // attached to step_finished MUST match the outcome callIds by
    // construction — the runner reuses the same normalized list for
    // tool_call_started and tool_call_finished.
    const calcTalent: TalentEngine = {
      name: 'calculate',
      execute: async () => ({type: 'text', summary: '4'}) as TalentResult,
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'calculate', description: '', parameters: {}},
      }),
    };
    const dtTalent: TalentEngine = {
      name: 'datetime',
      execute: async () => ({type: 'text', summary: '8:28 AM'}) as TalentResult,
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'datetime', description: '', parameters: {}},
      }),
    };
    talentRegistry.register(calcTalent);
    talentRegistry.register(dtTalent);
    palStore.pals = [
      {
        id: 'pal-1',
        type: 'local',
        name: 'Multi Pal',
        systemPrompt: '',
        parameters: {},
        parameterSchema: [],
        isSystemPromptChanged: false,
        useAIPrompt: false,
        source: 'local',
        pact: {
          talents: [
            {name: 'calculate', necessity: 'optional'},
            {name: 'datetime', necessity: 'optional'},
          ],
        },
      } as any,
    ];
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [],
        completionSettings: {},
        settingsSource: 'pal',
        activePalId: 'pal-1',
      } as any,
    ];
    chatSessionStore.activeSessionId = 'session-1';

    let turnIndex = 0;
    if (modelStore.context) {
      modelStore.context.completion = jest.fn().mockImplementation(async () => {
        turnIndex += 1;
        if (turnIndex === 1) {
          // Both ids are empty — runner MUST normalize them via the
          // per-run seed. The hook's appendToolCall receives the
          // normalized list (not the raw empties).
          return {
            text: '',
            content: '',
            tool_calls: [
              {
                id: '',
                type: 'function',
                function: {name: 'calculate', arguments: '{"e":"2+2"}'},
              },
              {
                id: '',
                type: 'function',
                function: {name: 'datetime', arguments: '{}'},
              },
            ],
          };
        }
        return {text: '4 at 8:28', content: '4 at 8:28'};
      });
    }

    const appendToolCallSpy = chatSessionStore.appendToolCall as jest.Mock;
    const appendToolOutcomeSpy =
      chatSessionStore.appendToolOutcome as jest.Mock;

    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    // appendToolCall called once for the multi-tool step (turn 0).
    const toolCallCalls = appendToolCallSpy.mock.calls.filter(
      c => (c[2] as Array<{id: string}>).length === 2,
    );
    expect(toolCallCalls).toHaveLength(1);
    const calls = toolCallCalls[0][2] as Array<{
      id: string;
      function: {name: string};
    }>;
    expect(calls).toHaveLength(2);
    expect(calls.every(c => c.id.length > 0)).toBe(true);
    // Distinct synthetic ids per index — runner appends `_<idx>` to
    // the seed.
    expect(calls[0].id).not.toBe(calls[1].id);

    // appendToolOutcome called twice (one per tool), each callId
    // matching one of the appendToolCall ids. This is the per-frame
    // id-match invariant for the multi-tool case.
    const outcomeIds = appendToolOutcomeSpy.mock.calls.map(
      c => (c[2] as {callId: string}).callId,
    );
    expect(outcomeIds).toHaveLength(2);
    const calledIds = calls.map(c => c.id);
    for (const oid of outcomeIds) {
      expect(calledIds).toContain(oid);
    }
    // Tool names match too — calculate came first, datetime second.
    expect(calls[0].function.name).toBe('calculate');
    expect(calls[1].function.name).toBe('datetime');

    // Cleanup
    (talentRegistry as any).engines.delete('calculate');
    (talentRegistry as any).engines.delete('datetime');
  });

  it('a later call that settles first still reaches appendToolOutcome after the earlier call', async () => {
    const settleOrder: string[] = [];
    let releaseCalculate!: () => void;
    const calcTalent: TalentEngine = {
      name: 'calculate',
      execute: () =>
        new Promise<TalentResult>(resolve => {
          releaseCalculate = () => {
            settleOrder.push('calculate');
            resolve({type: 'text', summary: '4'});
          };
        }),
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'calculate', description: '', parameters: {}},
      }),
    };
    const dtTalent: TalentEngine = {
      name: 'datetime',
      execute: () => {
        const settled = Promise.resolve<TalentResult>({
          type: 'text',
          summary: '8:28 AM',
        });
        settled.then(() => {
          settleOrder.push('datetime');
          releaseCalculate();
        });
        return settled;
      },
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'datetime', description: '', parameters: {}},
      }),
    };
    talentRegistry.register(calcTalent);
    talentRegistry.register(dtTalent);
    palStore.pals = [
      {
        id: 'pal-1',
        type: 'local',
        name: 'Multi Pal',
        systemPrompt: '',
        parameters: {},
        parameterSchema: [],
        isSystemPromptChanged: false,
        useAIPrompt: false,
        source: 'local',
        pact: {
          talents: [
            {name: 'calculate', necessity: 'optional'},
            {name: 'datetime', necessity: 'optional'},
          ],
        },
      } as any,
    ];
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [],
        completionSettings: {},
        settingsSource: 'pal',
        activePalId: 'pal-1',
      } as any,
    ];
    chatSessionStore.activeSessionId = 'session-1';

    let turnIndex = 0;
    if (modelStore.context) {
      modelStore.context.completion = jest.fn().mockImplementation(async () => {
        turnIndex += 1;
        if (turnIndex === 1) {
          return {
            text: '',
            content: '',
            tool_calls: [
              {
                id: 'c0',
                type: 'function',
                function: {name: 'calculate', arguments: '{}'},
              },
              {
                id: 'c1',
                type: 'function',
                function: {name: 'datetime', arguments: '{}'},
              },
            ],
          };
        }
        return {text: '4 at 8:28', content: '4 at 8:28'};
      });
    }

    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    expect(settleOrder).toEqual(['datetime', 'calculate']);
    const outcomeIds = (
      chatSessionStore.appendToolOutcome as jest.Mock
    ).mock.calls.map(c => (c[2] as {callId: string}).callId);
    expect(outcomeIds).toEqual(['c0', 'c1']);

    (talentRegistry as any).engines.delete('calculate');
    (talentRegistry as any).engines.delete('datetime');
  });

  it('#hookTest4 tool-followed-by-tool (multi-step chain): appendToolCall fires per step, ids stay distinct across steps', async () => {
    // Step 0: invoke calculate. Step 1: invoke datetime. Step 2: final
    // answer. The runner attaches a fresh normalized list to each
    // step_finished; ids carry `seed + turn` so they stay distinct
    // across steps.
    const calcTalent: TalentEngine = {
      name: 'calculate',
      execute: async () => ({type: 'text', summary: '4'}) as TalentResult,
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'calculate', description: '', parameters: {}},
      }),
    };
    const dtTalent: TalentEngine = {
      name: 'datetime',
      execute: async () => ({type: 'text', summary: '8:28 AM'}) as TalentResult,
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'datetime', description: '', parameters: {}},
      }),
    };
    talentRegistry.register(calcTalent);
    talentRegistry.register(dtTalent);
    palStore.pals = [
      {
        id: 'pal-1',
        type: 'local',
        name: 'Multi Pal',
        systemPrompt: '',
        parameters: {},
        parameterSchema: [],
        isSystemPromptChanged: false,
        useAIPrompt: false,
        source: 'local',
        pact: {
          talents: [
            {name: 'calculate', necessity: 'optional'},
            {name: 'datetime', necessity: 'optional'},
          ],
        },
      } as any,
    ];
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [],
        completionSettings: {},
        settingsSource: 'pal',
        activePalId: 'pal-1',
      } as any,
    ];
    chatSessionStore.activeSessionId = 'session-1';

    let turnIndex = 0;
    if (modelStore.context) {
      modelStore.context.completion = jest.fn().mockImplementation(async () => {
        turnIndex += 1;
        if (turnIndex === 1) {
          return {
            text: '',
            content: '',
            tool_calls: [
              {
                id: '',
                type: 'function',
                function: {name: 'calculate', arguments: '{"e":"2+2"}'},
              },
            ],
          };
        }
        if (turnIndex === 2) {
          return {
            text: '',
            content: '',
            tool_calls: [
              {
                id: '',
                type: 'function',
                function: {name: 'datetime', arguments: '{}'},
              },
            ],
          };
        }
        return {text: 'done', content: 'done'};
      });
    }

    const appendToolCallSpy = chatSessionStore.appendToolCall as jest.Mock;
    const appendToolOutcomeSpy =
      chatSessionStore.appendToolOutcome as jest.Mock;

    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    // appendToolCall fired twice — once per tool-using step.
    expect(appendToolCallSpy).toHaveBeenCalledTimes(2);

    // Each appendToolCall list has exactly one call with a non-empty
    // synthetic id; ids are distinct across steps (seed + turn).
    const allCalledIds = appendToolCallSpy.mock.calls.flatMap(c =>
      (c[2] as Array<{id: string}>).map(x => x.id),
    );
    expect(allCalledIds).toHaveLength(2);
    expect(allCalledIds.every(id => id.length > 0)).toBe(true);
    expect(new Set(allCalledIds).size).toBe(2); // distinct

    // appendToolOutcome called twice; each callId matches one of the
    // appendToolCall ids (per-frame id-match across step boundary).
    const outcomeIds = appendToolOutcomeSpy.mock.calls.map(
      c => (c[2] as {callId: string}).callId,
    );
    expect(outcomeIds).toHaveLength(2);
    for (const oid of outcomeIds) {
      expect(allCalledIds).toContain(oid);
    }

    // Cleanup
    (talentRegistry as any).engines.delete('calculate');
    (talentRegistry as any).engines.delete('datetime');
  });

  it('#hookTest5 abort during tool execution: appendToolCall still lands; partial outcomes preserved', async () => {
    // The runner finishes the in-flight tool call (executeOne is
    // not cancelled mid-execution per AgentRunner.ts:390-397
    // "Stop-mid-tool" comment). The abort is observed at the next
    // turn boundary. So appendToolCall + appendToolOutcome both
    // fire for the in-flight tool, then the run ends without a
    // follow-up turn. The hook's catch path is NOT entered (no
    // engineError). The id-match invariant must still hold.
    let resolveTalent: (r: TalentResult) => void;
    const talentPromise = new Promise<TalentResult>(resolve => {
      resolveTalent = resolve;
    });
    const slowTalent: TalentEngine = {
      name: 'calculate',
      execute: async () => talentPromise,
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'calculate', description: '', parameters: {}},
      }),
    };
    talentRegistry.register(slowTalent);
    palStore.pals = [
      {
        id: 'pal-1',
        type: 'local',
        name: 'Slow Pal',
        systemPrompt: '',
        parameters: {},
        parameterSchema: [],
        isSystemPromptChanged: false,
        useAIPrompt: false,
        source: 'local',
        pact: {talents: [{name: 'calculate', necessity: 'optional'}]},
      } as any,
    ];
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [],
        completionSettings: {},
        settingsSource: 'pal',
        activePalId: 'pal-1',
      } as any,
    ];
    chatSessionStore.activeSessionId = 'session-1';

    if (modelStore.context) {
      modelStore.context.completion = jest.fn().mockImplementation(async () => {
        return {
          text: '',
          content: '',
          tool_calls: [
            {
              id: '',
              type: 'function',
              function: {name: 'calculate', arguments: '{"e":"2+2"}'},
            },
          ],
        };
      });
    }

    const appendToolCallSpy = chatSessionStore.appendToolCall as jest.Mock;
    const appendToolOutcomeSpy =
      chatSessionStore.appendToolOutcome as jest.Mock;

    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );
    const sendPromise = result.current.handleSendPress(textMessage);

    // Wait until the runner has yielded step_finished + the
    // appendToolCall write has fired. We can't observe runner state
    // directly, so wait for the spy.
    await act(async () => {
      // Spin a few microtasks until appendToolCall fires.
      for (let i = 0; i < 30; i++) {
        if (appendToolCallSpy.mock.calls.length > 0) {
          break;
        }
        await Promise.resolve();
      }
    });

    expect(appendToolCallSpy).toHaveBeenCalled();
    const calls = appendToolCallSpy.mock.calls[0][2] as Array<{
      id: string;
    }>;
    expect(calls).toHaveLength(1);
    expect(calls[0].id.length).toBeGreaterThan(0);

    // Now press stop while the talent is still pending.
    await act(async () => {
      await result.current.handleStopPress();
    });

    // Resolve the talent so the runner can proceed past
    // tool_call_finished and observe signal.aborted.
    resolveTalent!({type: 'text', summary: '4'} as TalentResult);

    await act(async () => {
      await sendPromise;
    });

    // The outcome was emitted (executeOne completed); per-frame
    // id-match holds across the abort boundary.
    expect(appendToolOutcomeSpy).toHaveBeenCalled();
    const outcomeId = (
      appendToolOutcomeSpy.mock.calls[0][2] as {callId: string}
    ).callId;
    expect(outcomeId).toBe(calls[0].id);

    // Cleanup
    (talentRegistry as any).engines.delete('calculate');
  });

  it('a Stop before the tool phase of a six-call reply cancels every call and ends the lease', async () => {
    const execute = jest.fn(
      async (): Promise<TalentResult> => ({type: 'text', summary: '4'}),
    );
    talentRegistry.register({
      name: 'calculate',
      execute,
      toToolDefinition: () => ({
        type: 'function',
        function: {name: 'calculate', description: '', parameters: {}},
      }),
    });
    palStore.pals = [
      {
        id: 'pal-1',
        type: 'local',
        name: 'Calc Pal',
        systemPrompt: '',
        parameters: {},
        parameterSchema: [],
        isSystemPromptChanged: false,
        useAIPrompt: false,
        source: 'local',
        pact: {talents: [{name: 'calculate', necessity: 'optional'}]},
      } as any,
    ];
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [],
        completionSettings: {},
        settingsSource: 'pal',
        activePalId: 'pal-1',
      } as any,
    ];
    chatSessionStore.activeSessionId = 'session-1';
    modelStore.context!.completion = jest.fn().mockResolvedValue({
      text: '',
      content: '',
      tool_calls: [0, 1, 2, 3, 4, 5].map(i => ({
        id: `c${i}`,
        type: 'function',
        function: {name: 'calculate', arguments: '{"e":"2+2"}'},
      })),
    });

    try {
      const {result} = renderHook(() =>
        useChatSession({current: null}, textMessage.author, mockAssistant),
      );
      (chatSessionStore.appendToolCall as jest.Mock).mockImplementationOnce(
        async () => {
          result.current.handleStopPress();
        },
      );
      let settled = false;
      result.current.handleSendPress(textMessage).then(() => {
        settled = true;
      });
      await act(async () => {
        for (let i = 0; i < 1000 && !settled; i++) {
          await Promise.resolve();
        }
      });

      expect(settled).toBe(true);
      expect(modelStore.isGenerationBusy).toBe(false);
      const outcomes = (
        chatSessionStore.appendToolOutcome as jest.Mock
      ).mock.calls.map(call => call[2].result.errorMessage);
      expect(outcomes).toEqual(Array(6).fill('cancelled'));
      expect(execute).not.toHaveBeenCalled();
    } finally {
      (talentRegistry as any).engines.delete('calculate');
    }
  });

  it('#hookTest6 abort with no partial content: empty turn deleted via the store, no interrupted-metadata write', async () => {
    // The runner throws BEFORE any token / step_finished. The hook's
    // catch path sees `hasPartialContent === false` → calls
    // chatSessionStore.deleteMessageFromSession(sessionId, turnId) and skips the
    // updateMessage({metadata: {interrupted, copyable}}) write. A
    // system message about the failure is added below.
    const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
    const deleteMessageSpy = (
      chatSessionStore.deleteMessageFromSession as jest.Mock
    ).mockImplementation(async (sessionId: string, id: string) => {
      const owner = chatSessionStore.sessions.find(s => s.id === sessionId);
      if (owner) {
        owner.messages = owner.messages.filter(m => m.id !== id);
      }
    });

    if (modelStore.context) {
      modelStore.context.completion = jest
        .fn()
        .mockRejectedValueOnce(new Error('boom'));
    }
    const ref: {
      current: {createdAt: number; id: string; sessionId: string} | null;
    } = {current: null};

    // Seed the active session as empty so the empty-turn (created
    // by prepareCompletion) is the only message at error time.
    const turnId = 'empty-turn-id';
    chatSessionStore.sessions = [
      {
        id: 'session-1',
        title: '',
        date: '',
        messages: [],
        completionSettings: {},
        settingsSource: 'pal',
      },
    ] as any;
    chatSessionStore.activeSessionId = 'session-1';

    // The hook calls addMessageToCurrentSession twice: once for the
    // user text, once for the empty assistant turn. Tag the second
    // (assistant_turn) with our known id and inject it into the
    // session, so the catch path's lookup succeeds.
    let addCount = 0;
    (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mockImplementation(async (msg: any) => {
      addCount += 1;
      if (msg.type === 'assistant_turn') {
        msg.id = turnId;
        // Mirror real behaviour: the message lands in the active
        // session.
        const session = chatSessionStore.sessions.find(
          s => s.id === chatSessionStore.activeSessionId,
        );
        if (session) {
          (session as any).messages = [msg, ...session.messages];
        }
      } else {
        msg.id = `user-${addCount}`;
      }
    });

    const updateMessageSpy = chatSessionStore.updateMessage as jest.Mock;
    updateMessageSpy.mockClear();

    const {result} = renderHook(() =>
      useChatSession(ref, textMessage.author, mockAssistant),
    );
    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    // PATH B: the empty turn is deleted from its session.
    expect(deleteMessageSpy).toHaveBeenCalledWith('session-1', turnId);

    // No `interrupted` metadata write — that branch only fires when
    // partial content exists. Filter all updateMessage calls to
    // those that wrote metadata.interrupted=true; should be empty.
    const interruptedCalls = updateMessageSpy.mock.calls.filter(
      c => c[2]?.metadata?.interrupted === true,
    );
    expect(interruptedCalls).toHaveLength(0);

    // The empty turn is removed from the in-memory session.
    const session = chatSessionStore.sessions.find(s => s.id === 'session-1');
    expect(session?.messages.find((m: any) => m.id === turnId)).toBeUndefined();

    // A system message about the failure is added to surface the
    // error to the user.
    const sysCall = (
      chatSessionStore.addMessageToCurrentSession as jest.Mock
    ).mock.calls.find(c => c[0]?.metadata?.system === true);
    expect(sysCall).toBeDefined();

    deleteMessageSpy.mockReset();
    deleteMessageSpy.mockResolvedValue(undefined);
    errSpy.mockRestore();
  });

  describe('remote context accounting', () => {
    const REMOTE_WINDOW = 4096;

    // `activeModelCaps` is a computed over `capsFor()`, so the window is set up
    // by registering a remote model and the probe entry it resolves through.
    const activateRemoteModel = () => {
      modelStore.activeModelId = 'remote-1';
      modelStore.models = [
        {id: 'remote-1', origin: ModelOrigin.REMOTE, serverId: 'srv-1'} as any,
      ];
      (modelStore as any).activeContextSettings = undefined;
      serverStore.servers = [
        {
          id: 'srv-1',
          name: 'llama',
          url: 'http://localhost:8080',
          serverType: 'llama.cpp',
        } as any,
      ];
      serverStore.remoteCaps = {'remote-1': {contextLength: REMOTE_WINDOW}};
    };

    const bannerInput = () => ({
      effectiveNCtx: modelStore.activeModelCaps.effectiveContextLength,
      isRemote: true,
      htmlPreviewCount: 0,
      activeModelId: modelStore.activeModelId,
      dismissed: new Set<never>(),
    });

    it('a finished remote turn feeds the full banner a real count', async () => {
      activateRemoteModel();
      if (modelStore.context) {
        modelStore.context.completion = jest.fn().mockResolvedValue({
          text: 'cut off',
          content: 'cut off',
          timings: {prompt_n: 3900, cache_n: 0, predicted_n: 100},
          tokens_evaluated: 3900,
          tokens_predicted: 100,
          stopped_limit: 1,
        });
      }
      const {result} = renderHook(() =>
        useChatSession({current: null}, textMessage.author, mockAssistant),
      );

      await act(async () => {
        await result.current.handleSendPress(textMessage);
      });

      const snapshot = (
        chatSessionStore.recordCompletionSnapshot as jest.Mock
      ).mock.calls.at(-1)![0];
      expect(snapshot.used).toBe(4000);
      expect(snapshot.contextFull).toBe(true);
      expect(modelStore.activeModelCaps.effectiveContextLength).toBe(
        REMOTE_WINDOW,
      );

      expect(resolveBannerVariant(snapshot, bannerInput()).variant).toBe(
        'context-full',
      );
      // The window is only reached because the count is real: a zeroed one
      // fails the freshness gate and the banner never renders.
      expect(
        resolveBannerVariant({...snapshot, used: 0}, bannerInput()).variant,
      ).not.toBe('context-full');
    });

    it('re-probes remote capabilities once the model has provably answered', async () => {
      activateRemoteModel();
      if (modelStore.context) {
        modelStore.context.completion = jest.fn().mockResolvedValue({
          text: 'hello',
          content: 'hello',
        });
      }
      const {result} = renderHook(() =>
        useChatSession({current: null}, textMessage.author, mockAssistant),
      );

      await act(async () => {
        await result.current.handleSendPress(textMessage);
      });

      expect(modelStore.reprobeRemoteCapsAfterCompletion).toHaveBeenCalledTimes(
        1,
      );
    });

    it('leaves a finished local turn alone', async () => {
      if (modelStore.context) {
        modelStore.context.completion = jest.fn().mockResolvedValue({
          text: 'hello',
          content: 'hello',
        });
      }
      const {result} = renderHook(() =>
        useChatSession({current: null}, textMessage.author, mockAssistant),
      );

      await act(async () => {
        await result.current.handleSendPress(textMessage);
      });

      expect(
        modelStore.reprobeRemoteCapsAfterCompletion,
      ).not.toHaveBeenCalled();
    });

    it('a remote turn with no timings reports no count at all', async () => {
      activateRemoteModel();
      if (modelStore.context) {
        modelStore.context.completion = jest.fn().mockResolvedValue({
          text: 'hello',
          content: 'hello',
          tokens_predicted: 12,
        });
      }
      const {result} = renderHook(() =>
        useChatSession({current: null}, textMessage.author, mockAssistant),
      );

      await act(async () => {
        await result.current.handleSendPress(textMessage);
      });

      const snapshot = (
        chatSessionStore.recordCompletionSnapshot as jest.Mock
      ).mock.calls.at(-1)![0];
      // A predicted-only tally carries no prompt term and is not an occupancy
      // number, so there is nothing to report.
      expect(snapshot.used).toBeUndefined();
      expect(resolveBannerVariant(snapshot, bannerInput()).variant).not.toBe(
        'context-full',
      );
    });

    it('a remote turn whose timings carry rates but no token counts reports no count', async () => {
      activateRemoteModel();
      if (modelStore.context) {
        modelStore.context.completion = jest.fn().mockResolvedValue({
          text: 'hello',
          content: 'hello',
          // `timings` is present and carries no prompt term, so the presence
          // of the object says nothing about whether a count arrived.
          timings: {predicted_per_second: 80, prompt_per_second: 800},
          tokens_predicted: 600,
        });
      }
      const {result} = renderHook(() =>
        useChatSession({current: null}, textMessage.author, mockAssistant),
      );

      await act(async () => {
        await result.current.handleSendPress(textMessage);
      });

      const snapshot = (
        chatSessionStore.recordCompletionSnapshot as jest.Mock
      ).mock.calls.at(-1)![0];
      expect(snapshot.used).toBeUndefined();
      expect(resolveBannerVariant(snapshot, bannerInput()).variant).not.toBe(
        'context-full',
      );
    });

    it('an aborted turn with partial content reports no count, not zero', async () => {
      const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
      activateRemoteModel();
      if (modelStore.context) {
        modelStore.context.completion = jest
          .fn()
          .mockRejectedValueOnce(new Error('socket hang up'));
      }
      const ref: {
        current: {createdAt: number; id: string; sessionId: string} | null;
      } = {current: null};
      const {result} = renderHook(() =>
        useChatSession(ref, textMessage.author, mockAssistant),
      );

      const turnId = 'turn-remote-abort';
      chatSessionStore.sessions = [
        {
          id: 'session-1',
          title: '',
          date: '',
          messages: [
            {
              id: turnId,
              type: 'assistant_turn',
              author: assistant,
              createdAt: Date.now(),
              steps: [{content: 'partial'}],
              metadata: {copyable: true},
            } as MessageType.AssistantTurn,
          ],
          completionSettings: {},
          settingsSource: 'pal',
        },
      ] as any;
      (
        chatSessionStore.addMessageToCurrentSession as jest.Mock
      ).mockImplementation(async (msg: any) => {
        msg.id = turnId;
      });

      await act(async () => {
        await result.current.handleSendPress(textMessage);
      });

      const interruptedCall = (
        chatSessionStore.updateMessage as jest.Mock
      ).mock.calls.find(c => c[2]?.metadata?.interrupted === true);
      expect(interruptedCall).toBeDefined();
      const snapshot = interruptedCall![2].metadata.completionResult;
      expect(snapshot.contextFull).toBe(false);
      // Tokens were certainly consumed and no turn reported how many.
      expect(snapshot.used).toBeUndefined();
      expect('used' in snapshot).toBe(true);

      errSpy.mockRestore();
    });

    // The overflow paths never see a finished turn, so they pin `used` to the
    // session's context window. A remote session leaves the local context
    // settings unset, which is why reading the window from there suppressed
    // this banner outright.
    const overflowSession = (turnId: string, steps: any[]) => {
      chatSessionStore.sessions = [
        {
          id: 'session-1',
          title: '',
          date: '',
          messages: [
            {
              id: turnId,
              type: 'assistant_turn',
              author: assistant,
              createdAt: Date.now(),
              steps,
              metadata: {copyable: true},
            } as MessageType.AssistantTurn,
          ],
          completionSettings: {},
          settingsSource: 'pal',
        },
      ] as any;
      (
        chatSessionStore.addMessageToCurrentSession as jest.Mock
      ).mockImplementation(async (msg: any) => {
        msg.id = turnId;
      });
    };

    it('a prompt that overflows a remote window pins used to that window', async () => {
      const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
      activateRemoteModel();
      if (modelStore.context) {
        modelStore.context.completion = jest
          .fn()
          .mockRejectedValueOnce(new Error('Context is full'));
      }
      const ref: {
        current: {createdAt: number; id: string; sessionId: string} | null;
      } = {current: null};
      const {result} = renderHook(() =>
        useChatSession(ref, textMessage.author, mockAssistant),
      );
      overflowSession('turn-remote-overflow', []);

      await act(async () => {
        await result.current.handleSendPress(textMessage);
      });

      const snapshot = (
        chatSessionStore.recordCompletionSnapshot as jest.Mock
      ).mock.calls.at(-1)![0];
      expect(snapshot).toMatchObject({
        used: REMOTE_WINDOW,
        contextFull: true,
        isRemote: true,
      });
      expect(resolveBannerVariant(snapshot, bannerInput()).variant).toBe(
        'context-full',
      );

      // The window has to come from the probe: a remote session never
      // populates the local context settings, so a snapshot sourced from
      // those carries no count and the freshness gate rejects it.
      expect(modelStore.activeContextSettings?.n_ctx).toBeUndefined();
      expect(
        resolveBannerVariant(
          {...snapshot, used: modelStore.activeContextSettings?.n_ctx ?? 0},
          bannerInput(),
        ).variant,
      ).not.toBe('context-full');

      errSpy.mockRestore();
    });

    it('an overflow after partial output records the window on the turn', async () => {
      const errSpy = jest.spyOn(console, 'error').mockImplementation(() => {});
      activateRemoteModel();
      if (modelStore.context) {
        modelStore.context.completion = jest
          .fn()
          .mockRejectedValueOnce(new Error('Context is full'));
      }
      const ref: {
        current: {createdAt: number; id: string; sessionId: string} | null;
      } = {current: null};
      const {result} = renderHook(() =>
        useChatSession(ref, textMessage.author, mockAssistant),
      );
      overflowSession('turn-remote-overflow-partial', [{content: 'partial'}]);

      await act(async () => {
        await result.current.handleSendPress(textMessage);
      });

      const interruptedCall = (
        chatSessionStore.updateMessage as jest.Mock
      ).mock.calls.find(c => c[2]?.metadata?.interrupted === true);
      expect(interruptedCall).toBeDefined();
      const snapshot = interruptedCall![2].metadata.completionResult;
      expect(snapshot.contextFull).toBe(true);
      expect(snapshot.used).toBe(REMOTE_WINDOW);
      expect(resolveBannerVariant(snapshot, bannerInput()).variant).toBe(
        'context-full',
      );

      errSpy.mockRestore();
    });
  });

  it('a local turn with no evaluated count reports no count either', async () => {
    if (modelStore.context) {
      modelStore.context.completion = jest.fn().mockResolvedValue({
        text: 'hello',
        content: 'hello',
        timings: {predicted_per_second: 80},
        tokens_predicted: 600,
      });
    }
    const {result} = renderHook(() =>
      useChatSession({current: null}, textMessage.author, mockAssistant),
    );

    await act(async () => {
      await result.current.handleSendPress(textMessage);
    });

    const snapshot = (
      chatSessionStore.recordCompletionSnapshot as jest.Mock
    ).mock.calls.at(-1)![0];
    expect(snapshot.isRemote).toBe(false);
    expect(snapshot.used).toBeUndefined();
  });
});
